# Rhodes Financial v1.2.0 Patch

This update is designed to use the same persistent database at:

`~/Documents/Rhodes Financial/rhodes_financial.db`

It does **not** replace your database. `update.command` makes a safety copy before rebuilding the app.

## Update steps

1. Unzip this release.
2. Make sure Docker Desktop is running.
3. Double-click `update.command`.
4. The updater backs up the database, removes the old Rhodes Financial container, rebuilds v1.2.0, and opens `http://localhost:8000`.

The pre-update database copy is saved under:

`~/Documents/Rhodes Financial/backups/pre_update_DATE_TIME.db`

## v1.2.0 changes

- Replaced **Budget** in the primary navigation with a new **Expenses** page.
- Expenses defaults to the current month and supports a month picker.
- Added monthly expense summary cards: total expenses, transaction count, average transaction, and largest expense.
- Added category quick filters and category spending totals.
- Added a daily spending trend on the Expenses page.
- Added a monthly expense transaction table showing category and subcategory.
- Budget targets are still preserved and available under **More → Budget targets**.
- Dashboard cards, spending chart, and category rows are now clickable navigation shortcuts.
- Transaction Category/Subcategory dropdowns are dependent: selecting a category only shows its own active subcategories.
- The backend also validates category/subcategory pairs so stale browser values cannot create mismatched data.
- Added **Shopping → Amazon**.
- Removed **Food → Coffee** from active choices. Existing Coffee classifications are safely moved to **Food → Dining** during the migration.
- Amazon merchant heuristics now use **Shopping → Amazon**.
- Coffee-shop heuristics now use **Food → Dining**.

## Database migration

Schema/data migration version 2 is applied automatically on first startup of v1.2.0. It is idempotent and preserves your existing financial records.
