import csv
import hashlib
import io
import json
import math
import os
import re
import shutil
import statistics
import zipfile
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

import xlsxwriter
from pypdf import PdfReader
from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from .database import DATA_DIR, DB_PATH
from .models import (
    Account, BalanceSnapshot, Budget, Category, ImportLog, MerchantRule,
    ReviewItem, Setting, Subcategory, Tag, Transaction
)

DEFAULT_CATEGORIES = {
    "Housing": ["Rent/Mortgage", "Home Maintenance"],
    "Food": ["Groceries", "Dining"],
    "Transportation": ["Fuel", "Auto", "Transit"],
    "Shopping": ["General", "Clothing", "Electronics", "Amazon"],
    "Entertainment": ["Recreation", "Streaming", "Events"],
    "Healthcare": ["Medical", "Pharmacy", "Dental"],
    "Personal": ["Pets", "Personal Care", "Misc"],
    "Travel": ["Lodging", "Flights", "Other"],
    "Bills & Utilities": ["Phone", "Internet", "Utilities"],
    "Gifts": ["Gifts", "Charity"],
    "Education": ["Tuition", "Books"],
    "Income": ["Salary", "Bonus", "Gifts", "Reimbursement", "Refunds"],
    "Transfer": [],
    "Other": ["Unknown"],
}

DEFAULT_WIDGETS = [
    "cash_available", "investments", "income", "expenses", "savings",
    "largest_categories", "spending_graph"
]


def init_defaults(db: Session) -> None:
    if db.query(Account).count() == 0:
        for name, typ in [
            ("Checking", "checking"), ("Savings", "savings"),
            ("Credit Card", "credit"), ("Investments", "investment")
        ]:
            db.add(Account(name=name, account_type=typ, current_balance=0))
    if db.query(Category).count() == 0:
        order = 0
        for cname, subs in DEFAULT_CATEGORIES.items():
            cat = Category(name=cname, sort_order=order)
            db.add(cat)
            db.flush()
            for s in subs:
                db.add(Subcategory(category_id=cat.id, name=s))
            order += 1
    defaults = {
        "dashboard_widgets": json.dumps(DEFAULT_WIDGETS),
        "default_period": "month",
        "currency": "USD",
        "ai_enabled": "false",
        "theme": "dark",
        "export_sections": json.dumps(["summary", "transactions", "budget", "income"]),
        "export_visuals": json.dumps(["category", "trend", "income_vs_expenses", "budget_vs_actual", "yoy"]),
    }
    for k, v in defaults.items():
        if not db.get(Setting, k):
            db.add(Setting(key=k, value=v))
    db.commit()


def get_setting(db: Session, key: str, default: str = "") -> str:
    obj = db.get(Setting, key)
    return obj.value if obj else default


def set_setting(db: Session, key: str, value: str) -> None:
    obj = db.get(Setting, key)
    if obj:
        obj.value = value
    else:
        db.add(Setting(key=key, value=value))
    db.commit()


def normalize_merchant(desc: str) -> str:
    raw = re.sub(r"\s+", " ", desc.strip())
    substitutions = [
        (r"^AplPay\s+", ""), (r"^PP\*", ""), (r"^TST\*\s*", ""),
        (r"^SQ \*", ""), (r"\b\d{3}-\d{3}-\d{4}\b", ""),
        (r"\b\d{10}\b", ""),
    ]
    for pat, repl in substitutions:
        raw = re.sub(pat, repl, raw, flags=re.I)
    # trim common trailing city/state noise conservatively
    raw = re.sub(r"\s{2,}.*$", "", raw).strip()
    raw = re.sub(r"\s+#?\d{3,6}$", "", raw).strip()
    if not raw:
        raw = desc.strip()
    return raw.title() if raw.isupper() else raw


def _category_ids(db: Session, cat_name: str, sub_name: str | None = None):
    cat = db.query(Category).filter(func.lower(Category.name) == cat_name.lower()).first()
    sub = None
    if cat and sub_name:
        sub = db.query(Subcategory).filter(
            Subcategory.category_id == cat.id,
            func.lower(Subcategory.name) == sub_name.lower()
        ).first()
    return (cat.id if cat else None, sub.id if sub else None)


def classify_description(db: Session, description: str, classification: str = "", amount_sign: float | None = None) -> dict[str, Any]:
    d = description.upper()
    c = (classification or "").upper()
    merchant = normalize_merchant(description)

    # learned rules first
    rules = db.query(MerchantRule).filter(MerchantRule.active == True).all()
    for rule in rules:
        if rule.match_text.upper() in d:
            return {
                "merchant": rule.clean_name or merchant,
                "type": rule.transaction_type or "expense",
                "category_id": rule.category_id,
                "subcategory_id": rule.subcategory_id,
                "confidence": 1.0,
                "reason": "merchant rule",
            }

    if c in {"TRANSFER", "CREDIT_CARD_PAYM"} or "CREDIT CARD PAYMENT" in d or "CRCARDPMT" in d or "ONLINE PAYMENT THANK YOU" in d or "MOBILE PAYMENT - THANK YOU" in d:
        cat, sub = _category_ids(db, "Transfer")
        return {"merchant": merchant, "type": "transfer", "category_id": cat, "subcategory_id": sub, "confidence": .99, "reason": "transfer/payment"}
    if "TRANSFER TO" in d or "TRANSFER FROM" in d or "FUNDS TRANSFER" in d:
        cat, sub = _category_ids(db, "Transfer")
        return {"merchant": merchant, "type": "transfer", "category_id": cat, "subcategory_id": sub, "confidence": .95, "reason": "transfer wording"}
    if c == "PAYCHECK" or "PAYROLL" in d or "SALARY" in d or "IHC HEALTH SERVI" in d or "INTERMOUNTAIN HEALTHCARE" in d:
        cat, sub = _category_ids(db, "Income", "Salary")
        return {"merchant": merchant, "type": "income", "category_id": cat, "subcategory_id": sub, "confidence": .98, "reason": "payroll"}
    if c in {"DIVIDEND_CAP_GAI"} or "DIVIDEND" in d:
        cat, sub = _category_ids(db, "Income")
        return {"merchant": merchant, "type": "income", "category_id": cat, "subcategory_id": sub, "confidence": .9, "reason": "dividend"}

    classification_map = {
        "SHOPPING": ("Shopping", "General"),
        "FAST_FOOD": ("Food", "Dining"),
        "FOOD_DINING": ("Food", "Dining"),
        "RESTAURANTS": ("Food", "Dining"),
        "GROCERIES": ("Food", "Groceries"),
        "CLOTHING": ("Shopping", "Clothing"),
        "GAS": ("Transportation", "Fuel"),
        "AUTO_TRANSPORT": ("Transportation", "Auto"),
        "PARKING": ("Transportation", "Transit"),
        "PERSONAL_CARE": ("Personal", "Personal Care"),
        "HAIR": ("Personal", "Personal Care"),
        "GYM": ("Personal", "Misc"),
        "COFFEE_SHOPS": ("Food", "Dining"),
        "UTILITIES": ("Bills & Utilities", "Utilities"),
        "DOCTOR": ("Healthcare", "Medical"),
        "PHARMACY": ("Healthcare", "Pharmacy"),
        "HOME_IMPROVEMENT": ("Housing", "Home Maintenance"),
        "MORTGAGE_RENT": ("Housing", "Rent/Mortgage"),
        "HOBBIES": ("Entertainment", "Recreation"),
        "ENTERTAINMENT": ("Entertainment", "Recreation"),
        "AMUSEMENT": ("Entertainment", "Recreation"),
        "ARTS": ("Entertainment", "Events"),
        "MOVIES_DVDS": ("Entertainment", "Events"),
        "ELECTRONICS_SOFT": ("Shopping", "Electronics"),
        "BOOKS": ("Education", "Books"),
        "EDUCATION": ("Education", "Tuition"),
        "HOTEL": ("Travel", "Lodging"),
        "TRAVEL": ("Travel", "Other"),
        "SHIPPING": ("Shopping", "General"),
        "FEES_CHARGES": ("Other", "Unknown"),
    }
    if c in classification_map:
        cat_name, sub_name = classification_map[c]
        cat, sub = _category_ids(db, cat_name, sub_name)
        return {"merchant": merchant, "type": "expense", "category_id": cat, "subcategory_id": sub, "confidence": .88, "reason": "bank classification"}

    merchant_map = [
        (["COSTCO", "MACEY'S", "SMITH", "WALMART GROCERY", "TRADER JOE", "HARMONS"], ("Food", "Groceries")),
        (["CHICK-FIL-A", "TACO BELL", "BETO", "CAFE RIO", "RED TACOS", "TERIYAK", "CHICKEN SALAD", "ALBERTOS", "BARTOLOS"], ("Food", "Dining")),
        (["STARBUCKS", "SWIG", "CUPLA COFFEE"], ("Food", "Dining")),
        (["MAVERIK", "MURPHY EXPRESS", "CONOCO", "HOLIDAY 54", "CHEVRON", "SHELL"], ("Transportation", "Fuel")),
        (["NETFLIX", "SPOTIFY", "HULU", "DISNEY+", "AMAZON PRIME"], ("Entertainment", "Streaming")),
        (["SEATGEEK", "MEGAPLEX", "VAIL RESORT", "IKON PASS", "SKI 'N SEE", "FOX HOLLOW"], ("Entertainment", "Events")),
        (["TMOBILE", "T-MOBILE"], ("Bills & Utilities", "Phone")),
        (["ENBRIDGE", "PACIFICPOWER", "ROCKYMTN"], ("Bills & Utilities", "Utilities")),
        (["BARNES & NOBLE"], ("Education", "Books")),
        (["AMAZON"], ("Shopping", "Amazon")),
        (["BY LANEY GRACE", "BLINK"], ("Shopping", "General")),
        (["VET", "PETCO", "PETSMART", "CHEWY"], ("Personal", "Pets")),
    ]
    for keys, (cat_name, sub_name) in merchant_map:
        if any(k in d for k in keys):
            cat, sub = _category_ids(db, cat_name, sub_name)
            return {"merchant": merchant, "type": "expense", "category_id": cat, "subcategory_id": sub, "confidence": .86, "reason": "merchant heuristic"}

    # Generic signed CSV logic: negative values may be payment/refund/income; caller can override.
    if c == "INCOME":
        cat, sub = _category_ids(db, "Income")
        return {"merchant": merchant, "type": "income", "category_id": cat, "subcategory_id": sub, "confidence": .65, "reason": "bank classification"}

    cat, sub = _category_ids(db, "Other", "Unknown")
    return {"merchant": merchant, "type": "expense", "category_id": cat, "subcategory_id": sub, "confidence": .35, "reason": "unknown"}


def hash_transaction(account_id: int, txn_date: date, description: str, amount: float, txn_type: str, discriminator: str = "") -> str:
    payload = f"{account_id}|{txn_date.isoformat()}|{description.strip().upper()}|{amount:.2f}|{txn_type}|{discriminator}"
    return hashlib.sha256(payload.encode()).hexdigest()


def parse_date(value: str) -> date:
    value = value.strip()
    for fmt in ("%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d", "%m/%d"):
        try:
            parsed = datetime.strptime(value, fmt)
            if fmt == "%m/%d":
                parsed = parsed.replace(year=date.today().year)
            return parsed.date()
        except ValueError:
            pass
    raise ValueError(f"Unsupported date: {value}")


def detect_csv_kind(headers: list[str]) -> str:
    h = {x.strip().lower() for x in headers}
    if {"account number", "post date", "description", "debit", "credit"}.issubset(h):
        return "bank_history"
    if {"date", "description", "amount"}.issubset(h):
        return "card_activity"
    return "generic"


def detect_account(db: Session, filename: str, text_hint: str, kind: str) -> tuple[int | None, float, str]:
    accounts = db.query(Account).filter(Account.active == True).all()
    hint = f"{filename} {text_hint}".upper()
    for acct in accounts:
        if acct.last4 and acct.last4 in hint:
            return acct.id, .99, "matched last four digits"
        if acct.name.upper() in hint and acct.name.lower() not in {"checking", "savings", "credit card", "investments"}:
            return acct.id, .9, "matched account name"
    if kind == "card_activity":
        credits = [a for a in accounts if a.account_type == "credit"]
        if len(credits) == 1 and not credits[0].last4:
            return credits[0].id, .75, "only unconfigured credit-card account"
    if "MONEY MARKET" in hint and kind == "bank_history":
        # Descriptions can mention either direction, so only weakly infer savings.
        saves = [a for a in accounts if a.account_type == "savings"]
        if len(saves) == 1 and "DIVIDEND" in hint:
            return saves[0].id, .8, "money-market/dividend pattern"
    return None, 0.0, "account could not be identified confidently"


def preview_csv(db: Session, path: Path, filename: str) -> dict[str, Any]:
    text = path.read_text(errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    headers = reader.fieldnames or []
    kind = detect_csv_kind(headers)
    rows = list(reader)
    preview = []
    balance = None
    occurrence_counts: dict[str, int] = defaultdict(int)
    classification_counts = defaultdict(int)
    for row in rows[:5000]:
        try:
            is_refund = False
            if kind == "bank_history":
                txn_date = parse_date(row.get("Post Date", ""))
                desc = row.get("Description", "").strip()
                debit = float((row.get("Debit") or "0").replace(",", ""))
                credit = float((row.get("Credit") or "0").replace(",", ""))
                amount = debit if debit else credit
                sign = -1 if debit else 1
                classification = row.get("Classification", "")
                classification_counts[classification] += 1
                info = classify_description(db, desc, classification, sign)
                if credit and info["type"] == "expense" and info["confidence"] < .8:
                    cat, sub = _category_ids(db, "Income")
                    info.update(type="income", category_id=cat, subcategory_id=sub, confidence=.45, reason="unclassified account credit")
                if row.get("Balance") and balance is None:
                    try: balance = float(row["Balance"].replace(",", ""))
                    except ValueError: pass
            elif kind == "card_activity":
                txn_date = parse_date(row.get("Date", ""))
                desc = row.get("Description", "").strip()
                signed = float(row.get("Amount", "0").replace(",", ""))
                amount = abs(signed)
                info = classify_description(db, desc, "", signed)
                is_refund = False
                if signed < 0 and info["type"] == "expense":
                    # Card credits that are not recognized payments are treated as refunds.
                    # They reduce spending rather than being counted as income.
                    cat, sub = _category_ids(db, "Other", "Unknown")
                    info.update(type="expense", category_id=cat, subcategory_id=sub, confidence=.50, reason="negative card amount - possible refund")
                    is_refund = True
            else:
                continue
            base_key = f"{txn_date.isoformat()}|{desc.upper()}|{amount:.2f}|{info['type']}"
            occurrence_counts[base_key] += 1
            if kind == "bank_history":
                discriminator = f"balance={row.get('Balance','')}|check={row.get('Check','')}|occ={occurrence_counts[base_key]}"
            else:
                discriminator = f"occ={occurrence_counts[base_key]}"
            preview.append({
                "date": txn_date.isoformat(), "merchant": info["merchant"], "description": desc,
                "amount": round(amount, 2), "type": info["type"], "category_id": info["category_id"],
                "subcategory_id": info["subcategory_id"], "confidence": info["confidence"], "reason": info["reason"], "is_refund": is_refund,
                "dedupe_marker": discriminator,
            })
        except Exception:
            continue
    text_hint = " ".join(r.get("Description", "") for r in rows[:30])
    acct_id, acct_conf, acct_reason = detect_account(db, filename, text_hint, kind)
    return {
        "kind": kind, "rows": preview, "total_rows": len(preview), "suggested_account_id": acct_id,
        "account_confidence": acct_conf, "account_reason": acct_reason, "detected_balance": balance,
        "headers": headers,
    }


def extract_pdf_text(path: Path) -> str:
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def preview_pdf(db: Session, path: Path, filename: str) -> dict[str, Any]:
    text = extract_pdf_text(path)
    rows: list[dict[str, Any]] = []
    pdf_occurrence: dict[str, int] = defaultdict(int)
    statement_balance = None
    last4 = None
    product = None
    kind = "pdf_statement"
    m = re.search(r"Account ending in\s+(\d{4})", text, flags=re.I)
    if m: last4 = m.group(1)
    m = re.search(r"WELLS FARGO\s+([A-Z][A-Z \u00ae]+?CARD)(?:\n|Account)", text, flags=re.I)
    if m: product = re.sub(r"\s+", " ", m.group(1)).strip().title()
    m = re.search(r"New Balance\s+\$?([\d,]+\.\d{2})", text, flags=re.I)
    if m: statement_balance = float(m.group(1).replace(",", ""))

    # Wells Fargo statements: transaction lines include card ending + trans/post date + reference + desc + amount.
    wf_pattern = re.compile(
        r"(?:\b\d{4}\s+)?(\d{2}/\d{2})\s+(\d{2}/\d{2})\s+[A-Z0-9]+\s+(.+?)\s+([\d,]+\.\d{2})(?=\n|$)", re.I
    )
    statement_year = date.today().year
    period = re.search(r"Statement Period\s+\d{2}/\d{2}/(\d{4})\s+to", text, flags=re.I)
    if period: statement_year = int(period.group(1))
    for match in wf_pattern.finditer(text):
        trans_date, _, desc, amount_s = match.groups()
        desc = re.sub(r"\s+", " ", desc).strip()
        # Avoid totals/interest table lines accidentally matching.
        if any(x in desc.upper() for x in ["TOTAL ", "PURCHASES 23", "CASH ADVANCES 29"]):
            continue
        txn_date = datetime.strptime(f"{trans_date}/{statement_year}", "%m/%d/%Y").date()
        amount = float(amount_s.replace(",", ""))
        info = classify_description(db, desc)
        if "PAYMENT" in desc.upper() and "THANK YOU" in desc.upper():
            cat, sub = _category_ids(db, "Transfer")
            info.update(type="transfer", category_id=cat, subcategory_id=sub, confidence=.99)
        pdf_key = f"{txn_date.isoformat()}|{desc.upper()}|{amount:.2f}|{info['type']}"
        pdf_occurrence[pdf_key] += 1
        rows.append({
            "date": txn_date.isoformat(), "merchant": info["merchant"], "description": desc,
            "amount": amount, "type": info["type"], "category_id": info["category_id"],
            "subcategory_id": info["subcategory_id"], "confidence": info["confidence"], "reason": info["reason"], "is_refund": False,
            "dedupe_marker": f"occ={pdf_occurrence[pdf_key]}",
        })

    # Account match from last4 gets priority.
    acct_id = None; acct_conf = 0.0; acct_reason = "account could not be identified confidently"
    if last4:
        acct = db.query(Account).filter(Account.last4 == last4).first()
        if acct:
            acct_id, acct_conf, acct_reason = acct.id, .99, "matched statement account ending"
    if not acct_id:
        acct_id, acct_conf, acct_reason = detect_account(db, filename, f"{last4 or ''} {product or ''}", "card_activity")

    return {
        "kind": kind, "rows": rows, "total_rows": len(rows), "suggested_account_id": acct_id,
        "account_confidence": acct_conf, "account_reason": acct_reason, "detected_balance": statement_balance,
        "detected_last4": last4, "detected_product": product, "text_extracted": bool(text.strip()),
    }


def create_backup(label: str = "manual") -> Path:
    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    out = backup_dir / f"budget_backup_{stamp}_{label}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        if DB_PATH.exists():
            z.write(DB_PATH, arcname="rhodes_financial.db")
        metadata = {
            "created_at": datetime.now().isoformat(),
            "label": label,
            "app": "Rhodes Financial",
            "version": 1,
        }
        z.writestr("backup_info.json", json.dumps(metadata, indent=2))
    return out


def _review(db: Session, txn: Transaction | None, issue_type: str, message: str):
    db.add(ReviewItem(transaction_id=txn.id if txn else None, issue_type=issue_type, message=message))


def detect_post_import_issues(db: Session, imported_ids: list[int]) -> None:
    imported = db.query(Transaction).filter(Transaction.id.in_(imported_ids)).all() if imported_ids else []
    # Unknown categories / low confidence are marked at import; here detect possible paired transfers and recurring.
    for txn in imported:
        if txn.transaction_type == "transfer":
            other = db.query(Transaction).filter(
                Transaction.id != txn.id,
                Transaction.transaction_type == "transfer",
                Transaction.amount.between(txn.amount - .01, txn.amount + .01),
                Transaction.txn_date.between(txn.txn_date - timedelta(days=3), txn.txn_date + timedelta(days=3)),
                Transaction.account_id != txn.account_id,
            ).first()
            p2p = any(k in txn.raw_description.upper() for k in ["VENMO", "ZELLE", "CASH APP", "PAYPAL"])
            if not other and p2p and txn.txn_date >= date.today() - timedelta(days=180):
                existing = db.query(ReviewItem).join(Transaction, ReviewItem.transaction_id == Transaction.id).filter(
                    ReviewItem.issue_type == "possible_spending_transfer", ReviewItem.status == "open",
                    func.lower(Transaction.merchant) == txn.merchant.lower()
                ).first()
                if not existing:
                    _review(db, txn, "possible_spending_transfer", f"{txn.merchant} is an unmatched person-to-person transfer. Keep it as a transfer, reclassify it as spending, or exclude it?")

    # Recurring candidates by normalized merchant with >= 3 expenses and roughly monthly spacing.
    merchant_groups: dict[str, list[Transaction]] = defaultdict(list)
    all_expenses = db.query(Transaction).filter(Transaction.transaction_type == "expense", Transaction.excluded == False).all()
    for t in all_expenses:
        merchant_groups[t.merchant.lower()].append(t)
    for merchant, txns in merchant_groups.items():
        if len(txns) < 3:
            continue
        txns.sort(key=lambda x: x.txn_date)
        intervals = [(b.txn_date - a.txn_date).days for a, b in zip(txns, txns[1:])]
        if intervals and sum(1 for d in intervals[-4:] if 25 <= d <= 35) >= 2:
            for t in txns[-2:]:
                t.recurring = True
            latest = txns[-1]
            exists = db.query(ReviewItem).filter(ReviewItem.transaction_id == latest.id, ReviewItem.issue_type == "recurring_candidate", ReviewItem.status == "open").first()
            if not exists:
                _review(db, latest, "recurring_candidate", f"{latest.merchant} appears monthly. Mark it as a recurring charge/subscription?")

    # Unusually large expense relative to overall median.
    amounts = [t.amount for t in all_expenses if t.amount > 0]
    if len(amounts) >= 8:
        med = statistics.median(amounts)
        threshold = max(500.0, med * 6)
        for txn in imported:
            if txn.transaction_type == "expense" and txn.amount >= threshold and txn.txn_date >= date.today() - timedelta(days=180):
                exists = db.query(ReviewItem).filter(ReviewItem.transaction_id == txn.id, ReviewItem.issue_type == "large_transaction", ReviewItem.status == "open").first()
                if not exists:
                    _review(db, txn, "large_transaction", f"This ${txn.amount:,.2f} transaction is much larger than your typical expense. Include it in spending analytics?")
    db.commit()


def import_preview_rows(db: Session, preview: dict[str, Any], account_id: int, source_file: str) -> tuple[int, int]:
    if db.query(Transaction).count() > 0:
        create_backup("pre_import")
    account = db.get(Account, account_id)
    if not account:
        raise ValueError("Account not found")
    imported = 0; skipped = 0; imported_ids = []
    for row in preview.get("rows", []):
        txn_date = date.fromisoformat(row["date"])
        desc = row["description"]
        amount = float(row["amount"])
        txn_type = row["type"]
        h = hash_transaction(account_id, txn_date, desc, amount, txn_type, row.get("dedupe_marker", ""))
        if db.query(Transaction).filter(Transaction.original_hash == h).first():
            skipped += 1
            continue
        txn = Transaction(
            account_id=account_id, txn_date=txn_date, merchant=row["merchant"], raw_description=desc,
            amount=amount, transaction_type=txn_type, category_id=row.get("category_id"),
            subcategory_id=row.get("subcategory_id"), reviewed=row.get("confidence", 0) >= .8,
            is_refund=bool(row.get("is_refund", False)), original_hash=h, source_file=source_file,
        )
        db.add(txn); db.flush()
        imported_ids.append(txn.id); imported += 1
        if row.get("confidence", 0) < .8 and txn.txn_date >= date.today() - timedelta(days=180):
            existing_category_review = db.query(ReviewItem).join(Transaction, ReviewItem.transaction_id == Transaction.id).filter(
                ReviewItem.issue_type == "category", ReviewItem.status == "open", func.lower(Transaction.merchant) == txn.merchant.lower()
            ).first()
            if not existing_category_review:
                _review(db, txn, "category", f"Please review how {txn.merchant} should be categorized. Similar transactions can be updated together.")
        if txn.transaction_type == "income":
            txn.income_source = txn.merchant
        if txn.is_refund:
            _review(db, txn, "refund", f"This ${txn.amount:,.2f} credit looks like a refund. Choose the expense category it should reduce, or exclude it if it is not a refund.")

    if preview.get("detected_balance") is not None:
        account.current_balance = float(preview["detected_balance"])
        db.add(BalanceSnapshot(account_id=account.id, balance=account.current_balance, source="import"))
    if preview.get("detected_last4") and not account.last4:
        account.last4 = preview["detected_last4"]
    db.add(ImportLog(filename=source_file, file_type=Path(source_file).suffix.lower().lstrip("."), account_id=account_id, imported_count=imported, skipped_count=skipped))
    db.commit()
    detect_post_import_issues(db, imported_ids)
    return imported, skipped


def dashboard_period(period: str):
    today = date.today()
    if period == "week":
        start = today - timedelta(days=today.weekday())
        return start, today
    if period == "year":
        return date(today.year, 1, 1), today
    if period == "all":
        return date(1900, 1, 1), today
    return date(today.year, today.month, 1), today


def dashboard_data(db: Session, period: str = "month") -> dict[str, Any]:
    start, end = dashboard_period(period)
    txq = db.query(Transaction).filter(Transaction.txn_date.between(start, end), Transaction.excluded == False)
    expenses = txq.filter(Transaction.transaction_type == "expense").all()
    income = txq.filter(Transaction.transaction_type == "income").all()
    expense_total = sum((-t.amount if t.is_refund else t.amount) for t in expenses)
    income_total = sum(t.amount for t in income)
    savings = income_total - expense_total
    savings_rate = (savings / income_total * 100) if income_total else 0
    cash = sum(a.current_balance for a in db.query(Account).filter(Account.account_type.in_(["checking", "savings"]), Account.active == True).all())
    investments = sum(a.current_balance for a in db.query(Account).filter(Account.account_type == "investment", Account.active == True).all())

    cats = defaultdict(float)
    daily = defaultdict(float)
    for t in expenses:
        signed = -t.amount if t.is_refund else t.amount
        cat_key = (t.category_id, t.category.name if t.category else "Other")
        cats[cat_key] += signed
        daily[t.txn_date.isoformat()] += signed
    top_cats = [
        {"id": key[0], "name": key[1], "amount": amount}
        for key, amount in sorted(cats.items(), key=lambda x: x[1], reverse=True)[:6]
    ]
    daily_points = [{"date": k, "amount": round(v, 2)} for k, v in sorted(daily.items())]
    widgets = json.loads(get_setting(db, "dashboard_widgets", json.dumps(DEFAULT_WIDGETS)))
    return {
        "start": start, "end": end, "period": period, "income": income_total, "expenses": expense_total,
        "savings": savings, "savings_rate": savings_rate, "cash": cash, "investments": investments,
        "top_categories": top_cats, "daily_points": daily_points, "widgets": widgets,
    }



def expenses_month_data(db: Session, year: int, month: int, category_id: int | None = None) -> dict[str, Any]:
    start = date(year, month, 1)
    end = date(year + (month == 12), (month % 12) + 1, 1) - timedelta(days=1)
    base = db.query(Transaction).filter(
        Transaction.txn_date.between(start, end),
        Transaction.transaction_type == "expense",
        Transaction.excluded == False,
    )
    all_expenses = base.order_by(Transaction.txn_date.desc(), Transaction.id.desc()).all()
    visible = [t for t in all_expenses if category_id is None or t.category_id == category_id]

    category_totals = defaultdict(float)
    daily = defaultdict(float)
    for t in all_expenses:
        signed = -t.amount if t.is_refund else t.amount
        category_totals[t.category.name if t.category else "Other"] += signed
        daily[t.txn_date.isoformat()] += signed

    total = sum((-t.amount if t.is_refund else t.amount) for t in all_expenses)
    ordinary_expenses = [t for t in all_expenses if not t.is_refund]
    largest = max((t.amount for t in ordinary_expenses), default=0.0)
    count = len(all_expenses)
    average = total / count if count else 0.0
    filtered_total = sum((-t.amount if t.is_refund else t.amount) for t in visible)
    category_rows = sorted(category_totals.items(), key=lambda x: x[1], reverse=True)
    daily_points = [{"date": d, "amount": round(v, 2)} for d, v in sorted(daily.items())]
    return {
        "start": start, "end": end, "year": year, "month": month,
        "month_value": f"{year:04d}-{month:02d}", "label": start.strftime("%B %Y"),
        "transactions": visible, "total": float(total), "count": count, "average": float(average),
        "largest": float(largest), "filtered_total": float(filtered_total),
        "category_totals": category_rows, "daily_points": daily_points,
    }

def month_rollover(db: Session, year: int, month: int, budget: Budget) -> float:
    if not budget.rollover:
        return 0.0
    first = date(year, month, 1)
    prev_last = first - timedelta(days=1)
    prev_budget = db.query(Budget).filter(Budget.year == prev_last.year, Budget.month == prev_last.month, Budget.category_id == budget.category_id).first()
    if not prev_budget:
        return 0.0
    spent_rows = db.query(Transaction).filter(
        Transaction.transaction_type == "expense", Transaction.excluded == False,
        Transaction.category_id == budget.category_id,
        func.strftime("%Y", Transaction.txn_date) == f"{prev_last.year:04d}",
        func.strftime("%m", Transaction.txn_date) == f"{prev_last.month:02d}",
    ).all()
    spent = sum((-t.amount if t.is_refund else t.amount) for t in spent_rows)
    return max(0.0, prev_budget.amount - float(spent))


def budget_rows(db: Session, year: int, month: int) -> list[dict[str, Any]]:
    cats = db.query(Category).filter(Category.active == True, ~Category.name.in_(["Income", "Transfer"])).order_by(Category.sort_order).all()
    result = []
    for cat in cats:
        budget = db.query(Budget).filter(Budget.year == year, Budget.month == month, Budget.category_id == cat.id).first()
        spent_rows = db.query(Transaction).filter(
            Transaction.transaction_type == "expense", Transaction.excluded == False, Transaction.category_id == cat.id,
            func.strftime("%Y", Transaction.txn_date) == f"{year:04d}", func.strftime("%m", Transaction.txn_date) == f"{month:02d}",
        ).all()
        spent = sum((-t.amount if t.is_refund else t.amount) for t in spent_rows)
        rollover = month_rollover(db, year, month, budget) if budget else 0
        available = (budget.amount + rollover) if budget else None
        result.append({"category": cat, "budget": budget, "spent": float(spent), "rollover_amount": rollover,
                       "available": available, "remaining": (available - float(spent)) if available is not None else None})
    return result


def report_summary(db: Session, start: date, end: date) -> dict[str, Any]:
    txns = db.query(Transaction).filter(Transaction.txn_date.between(start, end), Transaction.excluded == False).all()
    expenses = [t for t in txns if t.transaction_type == "expense"]
    income = [t for t in txns if t.transaction_type == "income"]
    cat_totals = defaultdict(float)
    merchant_totals = defaultdict(float)
    daily = defaultdict(float)
    for t in expenses:
        signed = -t.amount if t.is_refund else t.amount
        cat_totals[t.category.name if t.category else "Other"] += signed
        merchant_totals[t.merchant] += signed
        daily[t.txn_date.isoformat()] += signed
    exp = sum((-t.amount if t.is_refund else t.amount) for t in expenses); inc = sum(t.amount for t in income)
    return {
        "transactions": txns, "expenses": expenses, "income_rows": income, "expense_total": exp,
        "income_total": inc, "savings": inc-exp, "savings_rate": ((inc-exp)/inc*100 if inc else 0),
        "category_totals": sorted(cat_totals.items(), key=lambda x: x[1], reverse=True),
        "merchant_totals": sorted(merchant_totals.items(), key=lambda x: x[1], reverse=True)[:10],
        "daily": dict(sorted(daily.items())), "start": start, "end": end,
    }


def export_xlsx(db: Session, scope: str, year: int | None = None, month: int | None = None) -> Path:
    today = date.today()
    if scope == "month":
        year = year or today.year; month = month or today.month
        start = date(year, month, 1)
        end = date(year + (month == 12), (month % 12) + 1, 1) - timedelta(days=1)
        filename = f"{start.strftime('%B').lower()}_{str(year)[2:]}.xlsx"
    elif scope == "year":
        year = year or today.year
        start, end = date(year, 1, 1), date(year, 12, 31)
        filename = f"{year}.xlsx"
    else:
        start, end = date(1900, 1, 1), today
        filename = "all_time.xlsx"

    out = DATA_DIR / "exports" / filename
    report = report_summary(db, start, end)
    sections = set(json.loads(get_setting(db, "export_sections", '["summary","transactions","budget","income"]')))
    visuals = set(json.loads(get_setting(db, "export_visuals", '["category","trend","income_vs_expenses","budget_vs_actual","yoy"]')))
    if not sections:
        sections = {"summary"}

    workbook = xlsxwriter.Workbook(out)
    fmt_title = workbook.add_format({"bold": True, "font_size": 18, "font_color": "#FFFFFF", "bg_color": "#111827"})
    fmt_head = workbook.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": "#374151", "border": 1})
    fmt_money = workbook.add_format({"num_format": "$#,##0.00"})
    fmt_pct = workbook.add_format({"num_format": "0.0%"})
    fmt_date = workbook.add_format({"num_format": "mm/dd/yyyy"})
    fmt_note = workbook.add_format({"font_color": "#6B7280", "italic": True})

    summary_sheet = None
    if "summary" in sections or visuals:
        summary_sheet = workbook.add_worksheet("Summary")
        summary_sheet.set_column("A:A", 24); summary_sheet.set_column("B:B", 18)
        summary_sheet.write("A1", "Rhodes Financial", fmt_title)
        summary_sheet.write("A3", "Period", fmt_head); summary_sheet.write("B3", f"{start:%m/%d/%Y} - {end:%m/%d/%Y}")
        metrics = [("Income", report["income_total"]), ("Expenses", report["expense_total"]), ("Savings", report["savings"])]
        for i, (label, value) in enumerate(metrics, 4):
            summary_sheet.write(i-1, 0, label, fmt_head); summary_sheet.write_number(i-1, 1, value, fmt_money)
        summary_sheet.write("A7", "Savings Rate", fmt_head); summary_sheet.write_number("B7", report["savings_rate"] / 100, fmt_pct)
        summary_sheet.write("A9", "Category", fmt_head); summary_sheet.write("B9", "Spending", fmt_head)
        for r, (name, val) in enumerate(report["category_totals"], 9):
            summary_sheet.write(r, 0, name); summary_sheet.write_number(r, 1, val, fmt_money)

        # Hidden helper tables for optional charts.
        helper_col = 7  # H
        summary_sheet.write(0, helper_col, "Date", fmt_head); summary_sheet.write(0, helper_col+1, "Daily spending", fmt_head)
        for r, (d, val) in enumerate(report["daily"].items(), 1):
            summary_sheet.write(r, helper_col, d); summary_sheet.write_number(r, helper_col+1, val)
        summary_sheet.write(0, helper_col+3, "Metric", fmt_head); summary_sheet.write(0, helper_col+4, "Amount", fmt_head)
        summary_sheet.write(1, helper_col+3, "Income"); summary_sheet.write_number(1, helper_col+4, report["income_total"])
        summary_sheet.write(2, helper_col+3, "Expenses"); summary_sheet.write_number(2, helper_col+4, report["expense_total"])

        chart_row = 2
        if "category" in visuals and report["category_totals"]:
            chart = workbook.add_chart({"type": "bar"})
            n = min(len(report["category_totals"]), 10)
            chart.add_series({"name":"Spending by category", "categories":["Summary",9,0,8+n,0], "values":["Summary",9,1,8+n,1]})
            chart.set_title({"name":"Spending by category"}); chart.set_legend({"none":True}); chart.set_style(10)
            summary_sheet.insert_chart(chart_row, 3, chart, {"x_scale":1.05,"y_scale":.95}); chart_row += 16
        if "trend" in visuals and report["daily"]:
            chart = workbook.add_chart({"type":"line"})
            n = len(report["daily"])
            chart.add_series({"name":"Daily spending", "categories":["Summary",1,helper_col,n,helper_col], "values":["Summary",1,helper_col+1,n,helper_col+1]})
            chart.set_title({"name":"Spending trend"}); chart.set_legend({"none":True}); chart.set_style(10)
            summary_sheet.insert_chart(chart_row, 3, chart, {"x_scale":1.05,"y_scale":.95}); chart_row += 16
        if "income_vs_expenses" in visuals:
            chart = workbook.add_chart({"type":"column"})
            chart.add_series({"name":"Amount", "categories":["Summary",1,helper_col+3,2,helper_col+3], "values":["Summary",1,helper_col+4,2,helper_col+4]})
            chart.set_title({"name":"Income vs expenses"}); chart.set_legend({"none":True}); chart.set_style(10)
            summary_sheet.insert_chart(chart_row, 3, chart, {"x_scale":1.05,"y_scale":.95}); chart_row += 16

        if "yoy" in visuals and scope == "month":
            prev_start = date(start.year-1, start.month, 1)
            prev_end = date(prev_start.year + (prev_start.month == 12), (prev_start.month % 12)+1, 1)-timedelta(days=1)
            prev_report = report_summary(db, prev_start, prev_end)
            summary_sheet.write(4, helper_col+3, str(start.year-1)); summary_sheet.write_number(4, helper_col+4, prev_report["expense_total"])
            summary_sheet.write(5, helper_col+3, str(start.year)); summary_sheet.write_number(5, helper_col+4, report["expense_total"])
            chart = workbook.add_chart({"type":"column"})
            chart.add_series({"name":"Expenses", "categories":["Summary",4,helper_col+3,5,helper_col+3], "values":["Summary",4,helper_col+4,5,helper_col+4]})
            chart.set_title({"name":"Year-over-year spending"}); chart.set_legend({"none":True}); chart.set_style(10)
            summary_sheet.insert_chart(chart_row, 3, chart, {"x_scale":1.05,"y_scale":.95}); chart_row += 16
        summary_sheet.set_column(helper_col, helper_col+5, None, None, {"hidden": True})

    if "transactions" in sections:
        wt = workbook.add_worksheet("Transactions")
        headers = ["Date", "Merchant", "Amount", "Type", "Category", "Subcategory", "Account", "Tags", "Notes"]
        for c, h in enumerate(headers): wt.write(0, c, h, fmt_head)
        wt.freeze_panes(1, 0)
        wt.set_column("A:A", 12); wt.set_column("B:B", 30); wt.set_column("C:C", 14); wt.set_column("D:I", 18)
        for r, t in enumerate(sorted(report["transactions"], key=lambda x: x.txn_date), 1):
            wt.write_datetime(r, 0, datetime.combine(t.txn_date, datetime.min.time()), fmt_date)
            wt.write(r, 1, t.merchant); wt.write_number(r, 2, (-t.amount if t.is_refund else t.amount), fmt_money); wt.write(r, 3, t.transaction_type + (" (refund)" if t.is_refund else ""))
            wt.write(r, 4, t.category.name if t.category else ""); wt.write(r, 5, t.subcategory.name if t.subcategory else "")
            wt.write(r, 6, t.account.name if t.account else ""); wt.write(r, 7, ", ".join(tag.name for tag in t.tags)); wt.write(r, 8, t.notes or "")

    if "income" in sections:
        wi = workbook.add_worksheet("Income")
        for c, h in enumerate(["Date", "Source", "Amount", "Category", "Subcategory"]): wi.write(0, c, h, fmt_head)
        wi.set_column("A:A", 12); wi.set_column("B:B", 30); wi.set_column("C:E", 18)
        for r, t in enumerate(sorted(report["income_rows"], key=lambda x: x.txn_date), 1):
            wi.write_datetime(r, 0, datetime.combine(t.txn_date, datetime.min.time()), fmt_date)
            wi.write(r, 1, t.income_source or t.merchant); wi.write_number(r, 2, t.amount, fmt_money)
            wi.write(r, 3, t.category.name if t.category else ""); wi.write(r, 4, t.subcategory.name if t.subcategory else "")

    budget_data = budget_rows(db, year or today.year, month or today.month)
    if "budget" in sections:
        wb = workbook.add_worksheet("Budget")
        for c, h in enumerate(["Category", "Budget", "Rollover", "Available", "Actual", "Remaining"]): wb.write(0, c, h, fmt_head)
        for r, row in enumerate(budget_data, 1):
            wb.write(r, 0, row["category"].name)
            budget_val = row["budget"].amount if row["budget"] else None
            vals = [budget_val, row["rollover_amount"], row["available"], row["spent"], row["remaining"]]
            for c, val in enumerate(vals, 1):
                if val is not None: wb.write_number(r, c, float(val), fmt_money)
        wb.set_column("A:A", 24); wb.set_column("B:F", 14)
        if "budget_vs_actual" in visuals:
            chart = workbook.add_chart({"type":"column"})
            n = len(budget_data)
            if n:
                chart.add_series({"name":"Budget", "categories":["Budget",1,0,n,0], "values":["Budget",1,3,n,3]})
                chart.add_series({"name":"Actual", "categories":["Budget",1,0,n,0], "values":["Budget",1,4,n,4]})
                chart.set_title({"name":"Budget vs actual"}); chart.set_style(10)
                wb.insert_chart(1, 8, chart, {"x_scale":1.15,"y_scale":1.0})
    elif "budget_vs_actual" in visuals and summary_sheet:
        summary_sheet.write(chart_row, 0, "Budget vs actual visual is available when the Budget section is included.", fmt_note)

    workbook.close()
    return out

