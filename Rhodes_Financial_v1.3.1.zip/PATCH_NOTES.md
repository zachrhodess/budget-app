# Rhodes Financial v1.3.1

This patch expands PDF importing, especially for brokerage/investment statements whose transaction tables do not extract cleanly as single text lines.

## Changes

- Added layout-aware PDF parsing with `pdfplumber` word coordinates.
- Added generic statement-type detection for bank, credit-card, investment/brokerage, and general financial PDFs.
- Reconstructs visually aligned transaction rows even when descriptions wrap across multiple PDF text lines.
- Added broader ending-balance and masked-account-number detection.
- Investment statements can automatically match the only active investment account when no last-four match exists.
- Investment deposits/withdrawals import as transfers rather than household income/expenses.
- Imported investment deposits/withdrawals also populate Investment Activity without duplicating an existing matching entry.
- Imported ending values continue to create balance snapshots and update the account's current balance.
- The import preview now labels detected statement type and investment activity type.
- Existing CSV importer and known PDF parsers remain available as earlier stages/fallbacks.

## Example supported behavior

A brokerage statement containing a visually aligned row such as a MoneyLink deposit can be reconstructed from positioned words, imported as a transfer/deposit, and paired with the statement's ending account value. Market appreciation is not treated as a cash transaction.

## Known limitation

Image-only/scanned PDFs still require OCR. This patch improves searchable/text PDFs and PDFs whose text extraction preserves word coordinates.

## Updating

Existing users should run `update.command` from the v1.3.1 folder. The updater preserves the database and creates a pre-update backup before rebuilding the container.
