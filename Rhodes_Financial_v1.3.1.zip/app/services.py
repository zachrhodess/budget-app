import csv
import hashlib
import io
import json
import math
import os
import re
import shutil
import statistics
import zipfile
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

import xlsxwriter
from pypdf import PdfReader
import pdfplumber
from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from .database import DATA_DIR, DB_PATH
from .models import (
    Account, BalanceSnapshot, Budget, Category, ImportLog, InvestmentActivity, MerchantRule,
    ReviewItem, Setting, Subcategory, Tag, Transaction
)

DEFAULT_CATEGORIES = {
    "Housing": ["Rent/Mortgage", "Home Maintenance"],
    "Food": ["Groceries", "Dining"],
    "Transportation": ["Fuel", "Auto", "Transit"],
    "Shopping": ["General", "Clothing", "Electronics", "Amazon"],
    "Entertainment": ["Recreation", "Streaming", "Events"],
    "Healthcare": ["Medical", "Pharmacy", "Dental"],
    "Personal": ["Pets", "Personal Care", "Misc"],
    "Travel": ["Lodging", "Flights", "Other"],
    "Bills & Utilities": ["Phone", "Internet", "Utilities"],
    "Gifts": ["Gifts", "Charity"],
    "Education": ["Tuition", "Books"],
    "Income": ["Salary", "Bonus", "Gifts", "Reimbursement", "Refunds"],
    "Transfer": [],
    "Other": ["Unknown"],
}

DEFAULT_WIDGETS = [
    "cash_available", "investments", "income", "expenses", "savings",
    "largest_categories", "spending_graph"
]


def init_defaults(db: Session) -> None:
    if db.query(Account).count() == 0:
        for name, typ in [
            ("Checking", "checking"), ("Savings", "savings"),
            ("Credit Card", "credit"), ("Investments", "investment")
        ]:
            db.add(Account(name=name, account_type=typ, current_balance=0))
    if db.query(Category).count() == 0:
        order = 0
        for cname, subs in DEFAULT_CATEGORIES.items():
            cat = Category(name=cname, sort_order=order)
            db.add(cat)
            db.flush()
            for s in subs:
                db.add(Subcategory(category_id=cat.id, name=s))
            order += 1
    defaults = {
        "dashboard_widgets": json.dumps(DEFAULT_WIDGETS),
        "default_period": "month",
        "currency": "USD",
        "ai_enabled": "false",
        "theme": "dark",
        "export_sections": json.dumps(["summary", "transactions", "budget", "income"]),
        "export_visuals": json.dumps(["category", "trend", "income_vs_expenses", "budget_vs_actual", "yoy"]),
    }
    for k, v in defaults.items():
        if not db.get(Setting, k):
            db.add(Setting(key=k, value=v))
    db.commit()


def get_setting(db: Session, key: str, default: str = "") -> str:
    obj = db.get(Setting, key)
    return obj.value if obj else default


def set_setting(db: Session, key: str, value: str) -> None:
    obj = db.get(Setting, key)
    if obj:
        obj.value = value
    else:
        db.add(Setting(key=key, value=value))
    db.commit()


def normalize_merchant(desc: str) -> str:
    raw = re.sub(r"\s+", " ", desc.strip())
    substitutions = [
        (r"^AplPay\s+", ""), (r"^PP\*", ""), (r"^TST\*\s*", ""),
        (r"^SQ \*", ""), (r"\b\d{3}-\d{3}-\d{4}\b", ""),
        (r"\b\d{10}\b", ""),
    ]
    for pat, repl in substitutions:
        raw = re.sub(pat, repl, raw, flags=re.I)
    # trim common trailing city/state noise conservatively
    raw = re.sub(r"\s{2,}.*$", "", raw).strip()
    raw = re.sub(r"\s+#?\d{3,6}$", "", raw).strip()
    if not raw:
        raw = desc.strip()
    return raw.title() if raw.isupper() else raw


def _category_ids(db: Session, cat_name: str, sub_name: str | None = None):
    cat = db.query(Category).filter(func.lower(Category.name) == cat_name.lower()).first()
    sub = None
    if cat and sub_name:
        sub = db.query(Subcategory).filter(
            Subcategory.category_id == cat.id,
            func.lower(Subcategory.name) == sub_name.lower()
        ).first()
    return (cat.id if cat else None, sub.id if sub else None)


def classify_description(db: Session, description: str, classification: str = "", amount_sign: float | None = None) -> dict[str, Any]:
    d = description.upper()
    c = (classification or "").upper()
    merchant = normalize_merchant(description)

    # learned rules first
    rules = db.query(MerchantRule).filter(MerchantRule.active == True).all()
    for rule in rules:
        if rule.match_text.upper() in d:
            return {
                "merchant": rule.clean_name or merchant,
                "type": rule.transaction_type or "expense",
                "category_id": rule.category_id,
                "subcategory_id": rule.subcategory_id,
                "confidence": 1.0,
                "reason": "merchant rule",
            }

    if c in {"TRANSFER", "CREDIT_CARD_PAYM"} or "CREDIT CARD PAYMENT" in d or "CRCARDPMT" in d or "ONLINE PAYMENT THANK YOU" in d or "MOBILE PAYMENT - THANK YOU" in d:
        cat, sub = _category_ids(db, "Transfer")
        return {"merchant": merchant, "type": "transfer", "category_id": cat, "subcategory_id": sub, "confidence": .99, "reason": "transfer/payment"}
    if "TRANSFER TO" in d or "TRANSFER FROM" in d or "FUNDS TRANSFER" in d:
        cat, sub = _category_ids(db, "Transfer")
        return {"merchant": merchant, "type": "transfer", "category_id": cat, "subcategory_id": sub, "confidence": .95, "reason": "transfer wording"}
    if c == "PAYCHECK" or "PAYROLL" in d or "SALARY" in d or "IHC HEALTH SERVI" in d or "INTERMOUNTAIN HEALTHCARE" in d:
        cat, sub = _category_ids(db, "Income", "Salary")
        return {"merchant": merchant, "type": "income", "category_id": cat, "subcategory_id": sub, "confidence": .98, "reason": "payroll"}
    if c in {"DIVIDEND_CAP_GAI"} or "DIVIDEND" in d:
        cat, sub = _category_ids(db, "Income")
        return {"merchant": merchant, "type": "income", "category_id": cat, "subcategory_id": sub, "confidence": .9, "reason": "dividend"}

    classification_map = {
        "SHOPPING": ("Shopping", "General"),
        "FAST_FOOD": ("Food", "Dining"),
        "FOOD_DINING": ("Food", "Dining"),
        "RESTAURANTS": ("Food", "Dining"),
        "GROCERIES": ("Food", "Groceries"),
        "CLOTHING": ("Shopping", "Clothing"),
        "GAS": ("Transportation", "Fuel"),
        "AUTO_TRANSPORT": ("Transportation", "Auto"),
        "PARKING": ("Transportation", "Transit"),
        "PERSONAL_CARE": ("Personal", "Personal Care"),
        "HAIR": ("Personal", "Personal Care"),
        "GYM": ("Personal", "Misc"),
        "COFFEE_SHOPS": ("Food", "Dining"),
        "UTILITIES": ("Bills & Utilities", "Utilities"),
        "DOCTOR": ("Healthcare", "Medical"),
        "PHARMACY": ("Healthcare", "Pharmacy"),
        "HOME_IMPROVEMENT": ("Housing", "Home Maintenance"),
        "MORTGAGE_RENT": ("Housing", "Rent/Mortgage"),
        "HOBBIES": ("Entertainment", "Recreation"),
        "ENTERTAINMENT": ("Entertainment", "Recreation"),
        "AMUSEMENT": ("Entertainment", "Recreation"),
        "ARTS": ("Entertainment", "Events"),
        "MOVIES_DVDS": ("Entertainment", "Events"),
        "ELECTRONICS_SOFT": ("Shopping", "Electronics"),
        "BOOKS": ("Education", "Books"),
        "EDUCATION": ("Education", "Tuition"),
        "HOTEL": ("Travel", "Lodging"),
        "TRAVEL": ("Travel", "Other"),
        "SHIPPING": ("Shopping", "General"),
        "FEES_CHARGES": ("Other", "Unknown"),
    }
    if c in classification_map:
        cat_name, sub_name = classification_map[c]
        cat, sub = _category_ids(db, cat_name, sub_name)
        return {"merchant": merchant, "type": "expense", "category_id": cat, "subcategory_id": sub, "confidence": .88, "reason": "bank classification"}

    merchant_map = [
        (["COSTCO", "MACEY'S", "SMITH", "WALMART GROCERY", "TRADER JOE", "HARMONS"], ("Food", "Groceries")),
        (["CHICK-FIL-A", "TACO BELL", "BETO", "CAFE RIO", "RED TACOS", "TERIYAK", "CHICKEN SALAD", "ALBERTOS", "BARTOLOS"], ("Food", "Dining")),
        (["STARBUCKS", "SWIG", "CUPLA COFFEE"], ("Food", "Dining")),
        (["MAVERIK", "MURPHY EXPRESS", "CONOCO", "HOLIDAY 54", "CHEVRON", "SHELL"], ("Transportation", "Fuel")),
        (["NETFLIX", "SPOTIFY", "HULU", "DISNEY+", "AMAZON PRIME"], ("Entertainment", "Streaming")),
        (["SEATGEEK", "MEGAPLEX", "VAIL RESORT", "IKON PASS", "SKI 'N SEE", "FOX HOLLOW"], ("Entertainment", "Events")),
        (["TMOBILE", "T-MOBILE"], ("Bills & Utilities", "Phone")),
        (["ENBRIDGE", "PACIFICPOWER", "ROCKYMTN"], ("Bills & Utilities", "Utilities")),
        (["BARNES & NOBLE"], ("Education", "Books")),
        (["AMAZON"], ("Shopping", "Amazon")),
        (["BY LANEY GRACE", "BLINK"], ("Shopping", "General")),
        (["VET", "PETCO", "PETSMART", "CHEWY"], ("Personal", "Pets")),
    ]
    for keys, (cat_name, sub_name) in merchant_map:
        if any(k in d for k in keys):
            cat, sub = _category_ids(db, cat_name, sub_name)
            return {"merchant": merchant, "type": "expense", "category_id": cat, "subcategory_id": sub, "confidence": .86, "reason": "merchant heuristic"}

    # Generic signed CSV logic: negative values may be payment/refund/income; caller can override.
    if c == "INCOME":
        cat, sub = _category_ids(db, "Income")
        return {"merchant": merchant, "type": "income", "category_id": cat, "subcategory_id": sub, "confidence": .65, "reason": "bank classification"}

    cat, sub = _category_ids(db, "Other", "Unknown")
    return {"merchant": merchant, "type": "expense", "category_id": cat, "subcategory_id": sub, "confidence": .35, "reason": "unknown"}


def hash_transaction(account_id: int, txn_date: date, description: str, amount: float, txn_type: str, discriminator: str = "") -> str:
    payload = f"{account_id}|{txn_date.isoformat()}|{description.strip().upper()}|{amount:.2f}|{txn_type}|{discriminator}"
    return hashlib.sha256(payload.encode()).hexdigest()


def parse_date(value: str) -> date:
    value = (value or "").strip().strip('"')
    value = re.sub(r"\s+", " ", value)
    formats = (
        "%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d", "%m/%d", "%m-%d-%Y", "%m-%d-%y",
        "%d/%m/%Y", "%d/%m/%y", "%b %d, %Y", "%B %d, %Y", "%b %d %Y", "%d %b %Y",
    )
    for fmt in formats:
        try:
            parsed = datetime.strptime(value, fmt)
            if fmt == "%m/%d":
                parsed = parsed.replace(year=date.today().year)
            return parsed.date()
        except ValueError:
            pass
    raise ValueError(f"Unsupported date: {value}")


def _norm_header(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (value or "").strip().lower()).strip()


CSV_ALIASES = {
    "date": ["date", "transaction date", "trans date", "posted date", "post date", "posting date", "effective date", "activity date"],
    "description": ["description", "merchant", "details", "detail", "transaction description", "memo", "payee", "name", "transaction", "narrative"],
    "amount": ["amount", "transaction amount", "amt", "value"],
    "debit": ["debit", "withdrawal", "withdrawals", "money out", "outflow", "charge", "charges", "paid out"],
    "credit": ["credit", "deposit", "deposits", "money in", "inflow", "payment received", "received"],
    "balance": ["balance", "running balance", "available balance", "ending balance"],
    "type": ["type", "transaction type", "category", "classification", "transaction category"],
}


def _header_score(header: str, aliases: list[str]) -> float:
    h = _norm_header(header)
    if not h:
        return 0.0
    best = 0.0
    for alias in aliases:
        a = _norm_header(alias)
        if h == a:
            best = max(best, 1.0)
        elif (a in h or h in a) and len(h.split()) >= 2 and len(a.split()) >= 2:
            best = max(best, .82)
        else:
            hs, aset = set(h.split()), set(a.split())
            if hs and aset:
                best = max(best, len(hs & aset) / len(hs | aset) * .72)
    return best


def _parse_money(value: str | None) -> float | None:
    if value is None:
        return None
    raw = str(value).strip()
    if not raw or raw.lower() in {"n/a", "na", "none", "null", "-", "--"}:
        return None
    neg = raw.startswith("(") and raw.endswith(")")
    raw = raw.replace("$", "").replace(",", "").replace(" ", "").replace("(", "").replace(")", "")
    raw = re.sub(r"[^0-9.+-]", "", raw)
    if raw in {"", "+", "-", "."}:
        return None
    try:
        val = float(raw)
        return -abs(val) if neg else val
    except ValueError:
        return None


def _csv_dialect_and_rows(text: str) -> tuple[list[str], list[dict[str, str]], str]:
    sample = text[:10000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    headers = [h.strip() for h in (reader.fieldnames or []) if h is not None]
    rows = []
    for raw in reader:
        row = {str(k).strip(): ("" if v is None else str(v).strip()) for k, v in raw.items() if k is not None}
        if any(v for v in row.values()):
            rows.append(row)
    return headers, rows, delimiter


def infer_csv_mapping(headers: list[str], rows: list[dict[str, str]]) -> dict[str, Any]:
    mapping: dict[str, str | None] = {k: None for k in CSV_ALIASES}
    scores: dict[str, float] = {}
    unused = list(headers)
    for role in ["date", "description", "amount", "debit", "credit", "balance", "type"]:
        ranked = sorted(((h, _header_score(h, CSV_ALIASES[role])) for h in unused), key=lambda x: x[1], reverse=True)
        if ranked and ranked[0][1] >= .45:
            mapping[role] = ranked[0][0]
            scores[role] = ranked[0][1]
            unused.remove(ranked[0][0])

    # Content-based fallback for date and numeric amount columns.
    sample_rows = rows[:40]
    if not mapping["date"]:
        ranked = []
        for h in headers:
            ok = 0; seen = 0
            for r in sample_rows:
                v = r.get(h, "").strip()
                if not v: continue
                seen += 1
                try: parse_date(v); ok += 1
                except Exception: pass
            ranked.append((h, ok/seen if seen else 0))
        if ranked:
            h, score = max(ranked, key=lambda x:x[1])
            if score >= .7: mapping["date"] = h; scores["date"] = score*.85

    if not mapping["amount"] and not (mapping["debit"] or mapping["credit"]):
        ranked=[]
        for h in headers:
            if h == mapping.get("date"): continue
            vals=[_parse_money(r.get(h)) for r in sample_rows if r.get(h, "").strip()]
            if vals:
                numeric=sum(v is not None for v in vals)/len(vals)
                ranked.append((h,numeric))
        if ranked:
            h,score=max(ranked,key=lambda x:x[1])
            if score >= .85: mapping["amount"] = h; scores["amount"] = score*.65

    if not mapping["description"]:
        candidates=[]
        for h in headers:
            if h in {mapping.get("date"),mapping.get("amount"),mapping.get("debit"),mapping.get("credit"),mapping.get("balance")}:
                continue
            vals=[r.get(h,"") for r in sample_rows if r.get(h,"")]
            if vals:
                avg=sum(len(v) for v in vals)/len(vals)
                candidates.append((h,avg))
        if candidates:
            h,avg=max(candidates,key=lambda x:x[1])
            if avg >= 4: mapping["description"] = h; scores["description"] = .55

    has_amount = bool(mapping["amount"] or mapping["debit"] or mapping["credit"])
    required_scores=[scores.get("date",0),scores.get("description",0)]
    if mapping["amount"]: required_scores.append(scores.get("amount",0))
    elif mapping["debit"] or mapping["credit"]: required_scores.append(max(scores.get("debit",0),scores.get("credit",0)))
    confidence = sum(required_scores)/len(required_scores) if required_scores and has_amount else 0
    return {"mapping": mapping, "scores": scores, "confidence": round(confidence,3), "ready": bool(mapping["date"] and mapping["description"] and has_amount)}


def detect_csv_kind(headers: list[str]) -> str:
    h = {_norm_header(x) for x in headers}
    if {"account number", "post date", "description", "debit", "credit"}.issubset(h):
        return "bank_history"
    if {"date", "description", "amount"}.issubset(h):
        return "card_activity"
    return "flexible_csv"


def _mapping_fingerprint(headers: list[str]) -> str:
    canonical = "|".join(sorted(_norm_header(h) for h in headers))
    return hashlib.sha256(canonical.encode()).hexdigest()[:20]


def _load_saved_mapping(db: Session, headers: list[str]) -> dict[str, Any] | None:
    raw = get_setting(db, f"import_mapping:{_mapping_fingerprint(headers)}", "")
    if not raw: return None
    try:
        obj=json.loads(raw)
        current=set(headers)
        if all((not v or v in current) for k,v in obj.get("mapping",{}).items() if k != "amount_mode"):
            return obj
    except Exception:
        pass
    return None


def save_import_mapping(db: Session, headers: list[str], mapping: dict[str, Any]) -> None:
    set_setting(db, f"import_mapping:{_mapping_fingerprint(headers)}", json.dumps({"mapping": mapping}))


def detect_account(db: Session, filename: str, text_hint: str, kind: str) -> tuple[int | None, float, str]:
    accounts = db.query(Account).filter(Account.active == True).all()
    hint = f"{filename} {text_hint}".upper()
    for acct in accounts:
        if acct.last4 and acct.last4 in hint:
            return acct.id, .99, "matched last four digits"
        if acct.name.upper() in hint and acct.name.lower() not in {"checking", "savings", "credit card", "investments"}:
            return acct.id, .9, "matched account name"
    if kind == "investment" or any(x in hint for x in ["BROKERAGE", "ROTH IRA", "TRADITIONAL IRA", "INVESTMENT ACCOUNT", "POSITIONS -", "EXCHANGE TRADED FUNDS"]):
        investments = [a for a in accounts if a.account_type == "investment"]
        if len(investments) == 1:
            return investments[0].id, .82, "investment statement matched the only active investment account"
    if kind in {"card_activity", "pdf_statement", "credit_card"} or any(x in hint for x in ["CREDIT CARD", "CARD ACTIVITY", "PURCHASES"]):
        credits = [a for a in accounts if a.account_type == "credit"]
        if len(credits) == 1 and not credits[0].last4:
            return credits[0].id, .70, "only unconfigured credit-card account"
    if "MONEY MARKET" in hint:
        saves = [a for a in accounts if a.account_type == "savings"]
        if len(saves) == 1 and "DIVIDEND" in hint:
            return saves[0].id, .8, "money-market/dividend pattern"
    return None, 0.0, "account could not be identified confidently"


def _amount_mode_from_context(filename: str, headers: list[str], mapping: dict[str, Any]) -> str:
    if mapping.get("debit") or mapping.get("credit"):
        return "debit_credit"
    hint = (filename + " " + " ".join(headers)).upper()
    if any(x in hint for x in ["CREDIT CARD", "CARD ACTIVITY", "PURCHASE AMOUNT", "CHARGE"]):
        return "positive_expense"
    return "negative_expense"


def _build_csv_preview(db: Session, rows: list[dict[str,str]], headers: list[str], filename: str, mapping: dict[str, Any], amount_mode: str) -> dict[str, Any]:
    preview=[]; balance=None; occurrence_counts=defaultdict(int); skipped=0
    for row in rows[:10000]:
        try:
            txn_date=parse_date(row.get(mapping.get("date") or "", ""))
            desc=(row.get(mapping.get("description") or "", "") or "").strip()
            if not desc: raise ValueError("blank description")
            classification=(row.get(mapping.get("type") or "", "") or "").strip()
            is_refund=False
            debit=_parse_money(row.get(mapping.get("debit"))) if mapping.get("debit") else None
            credit=_parse_money(row.get(mapping.get("credit"))) if mapping.get("credit") else None
            signed=_parse_money(row.get(mapping.get("amount"))) if mapping.get("amount") else None
            if amount_mode == "debit_credit":
                if debit not in {None,0}: signed=-abs(debit); amount=abs(debit)
                elif credit not in {None,0}: signed=abs(credit); amount=abs(credit)
                else: raise ValueError("blank amount")
            else:
                if signed is None or signed == 0: raise ValueError("blank amount")
                amount=abs(signed)
            info=classify_description(db, desc, classification, signed)
            if info["type"] not in {"transfer","income"}:
                if amount_mode == "positive_expense":
                    if signed is not None and signed < 0:
                        info.update(type="expense", confidence=max(info["confidence"],.55), reason="statement credit / possible refund")
                        is_refund=True
                    else:
                        info["type"]="expense"
                else: # bank-style signed amount / debit-credit
                    if signed is not None and signed > 0 and info["confidence"] < .8:
                        cat, sub = _category_ids(db, "Income")
                        info.update(type="income", category_id=cat, subcategory_id=sub, confidence=.55, reason="statement credit")
                    elif signed is not None and signed < 0:
                        info["type"]="expense"
            bal=_parse_money(row.get(mapping.get("balance"))) if mapping.get("balance") else None
            if bal is not None: balance=bal
            base_key=f"{txn_date.isoformat()}|{desc.upper()}|{amount:.2f}|{info['type']}"
            occurrence_counts[base_key]+=1
            preview.append({"date":txn_date.isoformat(),"merchant":info["merchant"],"description":desc,"amount":round(amount,2),"type":info["type"],"category_id":info["category_id"],"subcategory_id":info["subcategory_id"],"confidence":info["confidence"],"reason":info["reason"],"is_refund":is_refund,"dedupe_marker":f"occ={occurrence_counts[base_key]}"})
        except Exception:
            skipped+=1
    text_hint=" ".join((r.get(mapping.get("description") or "","") or "") for r in rows[:30])
    acct_id,acct_conf,acct_reason=detect_account(db,filename,text_hint,"flexible_csv")
    return {"kind":"flexible_csv","rows":preview,"total_rows":len(preview),"source_rows":len(rows),"skipped_rows":skipped,"suggested_account_id":acct_id,"account_confidence":acct_conf,"account_reason":acct_reason,"detected_balance":balance,"headers":headers,"column_mapping":mapping,"mapping_confidence":1.0,"amount_mode":amount_mode,"mapping_required":False}


def preview_csv(db: Session, path: Path, filename: str, mapping_override: dict[str, Any] | None = None, amount_mode: str | None = None) -> dict[str, Any]:
    text=path.read_text(errors="replace")
    headers,rows,delimiter=_csv_dialect_and_rows(text)
    if not headers:
        raise ValueError("This CSV does not appear to contain a header row.")
    saved=_load_saved_mapping(db,headers)
    inferred=infer_csv_mapping(headers,rows)
    mapping=(mapping_override or (saved or {}).get("mapping") or inferred["mapping"]).copy()
    known_kind = detect_csv_kind(headers)
    default_mode = "debit_credit" if known_kind == "bank_history" else ("positive_expense" if known_kind == "card_activity" else _amount_mode_from_context(filename,headers,mapping))
    mode=amount_mode or mapping.pop("amount_mode",None) or default_mode
    ready=bool(mapping.get("date") and mapping.get("description") and (mapping.get("amount") or mapping.get("debit") or mapping.get("credit")))
    uncertain = not (mapping_override or saved) and inferred["confidence"] < .72
    if not ready or uncertain:
        return {"kind":"flexible_csv","rows":[],"total_rows":0,"source_rows":len(rows),"suggested_account_id":None,"account_confidence":0,"account_reason":"choose the columns below","detected_balance":None,"headers":headers,"delimiter":delimiter,"column_mapping":mapping,"mapping_confidence":inferred["confidence"],"amount_mode":mode,"mapping_required":True,"sample_rows":rows[:8],"mapping_message":"Rhodes Financial could not confidently identify every required column." if not ready else "Rhodes Financial found a likely mapping, but confidence is low. Confirm the columns once and this format can be remembered for future imports."}
    result=_build_csv_preview(db,rows,headers,filename,mapping,mode)
    result.update(delimiter=delimiter,mapping_confidence=(1.0 if mapping_override or saved else inferred["confidence"]),sample_rows=rows[:8])
    # Low inference confidence should still preview if rows parsed; user sees exact mapping before import.
    return result


def extract_pdf_text(path: Path) -> str:
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def extract_pdf_layout_text(path: Path) -> str:
    """Extract a second text representation that better preserves visual word grouping."""
    try:
        with pdfplumber.open(str(path)) as pdf:
            return "\n".join((page.extract_text(x_tolerance=2, y_tolerance=3) or "") for page in pdf.pages)
    except Exception:
        return ""


def _statement_year(text: str) -> int:
    patterns = [
        r"Statement Period\s+(?:[A-Za-z]+\s+)?\d{1,2}(?:[-–]\d{1,2})?,\s*(\d{4})",
        r"Statement Period\s+\d{1,2}/\d{1,2}(?:\s*[-–]\s*\d{1,2}/\d{1,2})?/(\d{4})",
        r"Statement Date\s*:?\s*\d{1,2}/\d{1,2}/(\d{4})",
        r"through\s+\w+\s+\d{1,2},\s*(\d{4})",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I)
        if m:
            return int(m.group(1))
    years = [int(y) for y in re.findall(r"\b(20\d{2})\b", text)]
    return max(years) if years else date.today().year


def _detect_pdf_statement_type(text: str) -> tuple[str, float]:
    up = text.upper()
    scores = {
        "investment": sum(1 for x in ["POSITIONS", "MARKET VALUE", "COST BASIS", "BROKERAGE", "ETF", "EXCHANGE TRADED FUNDS", "DIVIDENDS/INTEREST"] if x in up),
        "credit_card": sum(1 for x in ["CREDIT CARD", "CREDIT LIMIT", "MINIMUM PAYMENT", "PURCHASES", "PAYMENT DUE", "CASH ADVANCE"] if x in up),
        "bank": sum(1 for x in ["CHECKING", "SAVINGS", "BEGINNING BALANCE", "ENDING BALANCE", "DEPOSITS", "WITHDRAWALS", "ACCOUNT SUMMARY"] if x in up),
    }
    kind, score = max(scores.items(), key=lambda x: x[1])
    if score == 0:
        return "general_financial", 0.35
    return kind, min(0.98, 0.52 + score * 0.09)


def _extract_account_last4(text: str) -> str | None:
    patterns = [
        r"(?:Account ending in|ending in)\s*[*xX-]*(\d{4})\b",
        r"Account\s*Number\s*(?:\d{1,8}-)?(\d{4})\b",
        r"Account\s*Number.{0,80}?(?:\d{1,8}-)?(\d{4})\b",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I | re.S)
        if m:
            return m.group(1)
    return None


def _extract_statement_balance(text: str) -> float | None:
    patterns = [
        r"Ending Account Value(?:\s+as of\s+\d{1,2}/\d{1,2})?\s*\$?([\d,]+\.\d{2})",
        r"(?:New|Ending|Closing) Balance(?:\s+as of\s+\d{1,2}/\d{1,2})?\s*\$?([\d,]+\.\d{2})",
        r"Account Ending Value.{0,40}?\$?([\d,]+\.\d{2})",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I | re.S)
        if m:
            try:
                return float(m.group(1).replace(",", ""))
            except ValueError:
                pass
    return None


def _group_pdf_words(words: list[dict[str, Any]], y_tolerance: float = 3.0) -> list[dict[str, Any]]:
    """Group positioned PDF words into visual rows while preserving x coordinates."""
    rows: list[dict[str, Any]] = []
    for word in sorted(words, key=lambda w: (float(w.get("top", 0)), float(w.get("x0", 0)))):
        top = float(word.get("top", 0))
        target = None
        for row in rows[-4:]:
            if abs(row["top"] - top) <= y_tolerance:
                target = row
                break
        if target is None:
            target = {"top": top, "words": []}
            rows.append(target)
        target["words"].append(word)
    for row in rows:
        row["words"].sort(key=lambda w: float(w.get("x0", 0)))
        row["text"] = " ".join(w.get("text", "") for w in row["words"]).strip()
    return rows


def _parse_pdf_date(raw: str, year: int) -> date | None:
    value = raw.strip()
    try:
        if re.fullmatch(r"\d{1,2}/\d{1,2}", value):
            value = f"{value}/{year}"
        elif re.match(r"^[A-Za-z]", value) and not re.search(r"\d{4}", value):
            value = f"{value} {year}"
        return parse_date(value)
    except Exception:
        return None


def _layout_pdf_rows(db: Session, path: Path, text: str, year: int, statement_type: str) -> list[dict[str, Any]]:
    """Reconstruct transaction rows from visual PDF layout instead of relying on line text.

    The parser is intentionally institution-agnostic: it looks for transaction/activity section
    headings, then rows beginning with dates and ending with plausible money values. Wrapped
    description lines are attached to the preceding row.
    """
    results: list[dict[str, Any]] = []
    occurrence = defaultdict(int)
    section_start_re = re.compile(r"\b(TRANSACTION DETAILS|TRANSACTIONS|ACCOUNT ACTIVITY|ACTIVITY DETAILS|PURCHASES AND OTHER CHARGES|DEPOSITS AND ADDITIONS|WITHDRAWALS AND OTHER DEBITS)\b", re.I)
    section_stop_re = re.compile(r"\b(BANK SWEEP ACTIVITY|POSITIONS|ACCOUNT SUMMARY|TERMS AND CONDITIONS|ENDNOTES|FEES|INTEREST CHARGE CALCULATION|PAYMENT INFORMATION)\b", re.I)
    date_token = re.compile(r"^(?:\d{1,2}/\d{1,2}(?:/\d{2,4})?|\d{4}-\d{2}-\d{2})$")

    try:
        with pdfplumber.open(str(path)) as pdf:
            for page in pdf.pages:
                words = page.extract_words(use_text_flow=False, keep_blank_chars=False) or []
                rows = _group_pdf_words(words)
                active = False
                pending: dict[str, Any] | None = None
                for visual in rows:
                    txt = visual["text"]
                    compact = re.sub(r"\s+", " ", txt).strip()
                    if section_start_re.search(compact):
                        active = True
                        pending = None
                        continue
                    if active and section_stop_re.search(compact):
                        if pending:
                            results.append(pending); pending = None
                        active = False
                        continue
                    if not active:
                        continue

                    ws = visual["words"]
                    first_date = next((w for w in ws if float(w.get("x0", 0)) < page.width * 0.18 and date_token.match(w.get("text", ""))), None)
                    if first_date:
                        if pending:
                            results.append(pending)
                        txn_date = _parse_pdf_date(first_date["text"], year)
                        if not txn_date:
                            pending = None
                            continue
                        money_candidates = []
                        for w in ws:
                            val = _parse_money(w.get("text", ""))
                            if val is not None and re.search(r"\d[\d,]*\.\d{2}", w.get("text", "")):
                                money_candidates.append((float(w.get("x0", 0)), val, w.get("text", "")))
                        if not money_candidates:
                            pending = {"_date": txn_date, "_desc": compact, "_amount": None, "_page_width": page.width}
                            continue
                        # Transaction amount is generally among the rightmost numeric columns.
                        x, signed, raw_money = max(money_candidates, key=lambda t: t[0])
                        left_words = [w.get("text", "") for w in ws if float(w.get("x0", 0)) > float(first_date.get("x1", 0)) + 2 and float(w.get("x0", 0)) < x - 5]
                        desc = " ".join(left_words).strip(" -|,") or compact
                        pending = {"_date": txn_date, "_desc": desc, "_amount": signed, "_page_width": page.width}
                    elif pending:
                        # Wrapped descriptions usually appear under the middle description columns.
                        textual = [w for w in ws if not re.fullmatch(r"\$?[\d,.()%+-]+", w.get("text", ""))]
                        if textual:
                            minx = min(float(w.get("x0", 0)) for w in textual)
                            if page.width * 0.18 <= minx <= page.width * 0.75:
                                extra = " ".join(w.get("text", "") for w in textual).strip()
                                if extra and len(extra) < 180:
                                    pending["_desc"] = (pending.get("_desc", "") + " " + extra).strip()
                if pending:
                    results.append(pending)
    except Exception:
        return []

    normalized: list[dict[str, Any]] = []
    skip_desc = ("TOTAL TRANSACTIONS", "BEGINNING BALANCE", "ENDING BALANCE", "INTEREST RATE")
    for row in results:
        if row.get("_amount") is None:
            continue
        desc = re.sub(r"\s+", " ", row.get("_desc", "")).strip()
        if len(desc) < 2 or any(x in desc.upper() for x in skip_desc):
            continue
        signed = float(row["_amount"])
        amount = abs(signed)
        txn_date = row["_date"]
        up = desc.upper()
        activity_type = None
        if statement_type == "investment":
            if any(x in up for x in ["DEPOSIT", "CONTRIBUTION", "MONEYLINK", "BANK CREDIT", "TRANSFER IN", "JOURNAL IN"]):
                activity_type = "deposit"
            elif any(x in up for x in ["WITHDRAWAL", "DISTRIBUTION", "TRANSFER OUT", "JOURNAL OUT"]):
                activity_type = "withdrawal"
            elif any(x in up for x in ["DIVIDEND", "INTEREST"]):
                activity_type = "dividend"
            elif any(x in up for x in ["BUY", "PURCHASE"]):
                activity_type = "purchase"
            elif any(x in up for x in ["SELL", "REDEMPTION"]):
                activity_type = "sale"
            elif any(x in up for x in ["FEE", "EXPENSE"]):
                activity_type = "fee"

        info = classify_description(db, desc, "", signed)
        is_refund = False
        if statement_type == "investment":
            # Brokerage funding is movement between owned accounts, not household income/spending.
            if activity_type in {"deposit", "withdrawal", "purchase", "sale"}:
                cat, sub = _category_ids(db, "Transfer")
                info.update(type="transfer", category_id=cat, subcategory_id=sub, confidence=max(info.get("confidence", 0), .92), reason=f"investment {activity_type}")
            elif activity_type == "dividend":
                cat, sub = _category_ids(db, "Income")
                info.update(type="income", category_id=cat, subcategory_id=sub, confidence=max(info.get("confidence", 0), .88), reason="investment dividend/interest")
            elif activity_type == "fee":
                info.update(type="expense", confidence=max(info.get("confidence", 0), .85), reason="investment fee")
            else:
                cat, sub = _category_ids(db, "Transfer")
                info.update(type="transfer", category_id=cat, subcategory_id=sub, confidence=max(info.get("confidence", 0), .7), reason="investment activity")
        elif info["type"] not in {"transfer", "income"}:
            if statement_type == "credit_card":
                if signed < 0:
                    info.update(type="expense", confidence=max(info["confidence"], .55), reason="statement credit / possible refund")
                    is_refund = True
                else:
                    info["type"] = "expense"
            else:
                if signed > 0 and info["confidence"] < .8:
                    cat, sub = _category_ids(db, "Income")
                    info.update(type="income", category_id=cat, subcategory_id=sub, confidence=.55, reason="statement credit")
                elif signed < 0:
                    info["type"] = "expense"
        key = f"{txn_date.isoformat()}|{desc.upper()}|{amount:.2f}|{info['type']}"
        occurrence[key] += 1
        normalized.append({
            "date": txn_date.isoformat(), "merchant": info["merchant"], "description": desc,
            "amount": amount, "type": info["type"], "category_id": info["category_id"],
            "subcategory_id": info["subcategory_id"], "confidence": info["confidence"],
            "reason": info["reason"], "is_refund": is_refund,
            "activity_type": activity_type, "dedupe_marker": f"occ={occurrence[key]}",
        })
    return normalized


def _generic_pdf_rows(db: Session, text: str, year: int, statement_type: str = "general_financial") -> list[dict[str, Any]]:
    out=[]; occurrence=defaultdict(int)
    skip_words=("BEGINNING BALANCE","ENDING BALANCE","NEW BALANCE","TOTAL FEES","TOTAL INTEREST","TOTAL PURCHASES","PAYMENT INFORMATION","ACCOUNT SUMMARY","MINIMUM PAYMENT","CREDIT LIMIT")
    lines=[re.sub(r"\s+"," ",ln).strip() for ln in text.splitlines() if ln.strip()]
    date_re=r"(?P<date>\d{1,2}/\d{1,2}(?:/\d{2,4})?|\d{4}-\d{2}-\d{2}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2})"
    money_re=r"\(?[-+]?\$?[\d,]+\.\d{2}\)?"
    for ln in lines:
        up=ln.upper()
        if any(w in up for w in skip_words): continue
        m=re.match(rf"^{date_re}\s+(?P<body>.+)$",ln,re.I)
        if not m: continue
        body=m.group("body")
        monies=list(re.finditer(money_re,body))
        if not monies: continue
        chosen=monies[-1]
        if len(monies)>=2 and re.search(r"BAL(?:ANCE)?", body[max(0,monies[-1].start()-15):monies[-1].start()], re.I): chosen=monies[-2]
        desc=body[:chosen.start()].strip(" -|\t")
        desc=re.sub(r"^\d{1,2}/\d{1,2}(?:/\d{2,4})?\s+", "", desc)
        desc=re.sub(r"^[A-Z0-9]{8,}\s+", "", desc)
        if len(desc)<2: continue
        try:
            raw_date=m.group("date")
            txn_date=_parse_pdf_date(raw_date, year)
            if not txn_date: continue
            signed=_parse_money(chosen.group(0))
            if signed is None: continue
            amount=abs(signed)
            info=classify_description(db,desc,"",signed)
            is_refund=False
            if info["type"] not in {"transfer","income"}:
                if statement_type == "credit_card":
                    if signed < 0:
                        is_refund=True; info.update(type="expense",confidence=max(info["confidence"],.5),reason="statement credit / possible refund")
                    else: info["type"]="expense"
                else:
                    if signed > 0 and info["confidence"] < .8:
                        cat, sub = _category_ids(db, "Income")
                        info.update(type="income", category_id=cat, subcategory_id=sub, confidence=.55, reason="statement credit")
                    elif signed < 0:
                        info["type"]="expense"
            key=f"{txn_date.isoformat()}|{desc.upper()}|{amount:.2f}|{info['type']}"; occurrence[key]+=1
            out.append({"date":txn_date.isoformat(),"merchant":info["merchant"],"description":desc,"amount":amount,"type":info["type"],"category_id":info["category_id"],"subcategory_id":info["subcategory_id"],"confidence":info["confidence"],"reason":info["reason"],"is_refund":is_refund,"dedupe_marker":f"occ={occurrence[key]}"})
        except Exception: pass
    return out


def preview_pdf(db: Session, path: Path, filename: str) -> dict[str, Any]:
    text=extract_pdf_text(path)
    layout_text=extract_pdf_layout_text(path)
    analysis_text = text + "\n" + layout_text
    rows=[]; occurrence=defaultdict(int)
    last4=_extract_account_last4(analysis_text)
    statement_balance=_extract_statement_balance(analysis_text)
    statement_type, statement_type_confidence = _detect_pdf_statement_type(analysis_text)
    year=_statement_year(analysis_text)

    # Known high-quality layout remains fast, but all other files now get a position-aware parser.
    wf_pattern=re.compile(r"(?:\b\d{4}\s+)?(\d{2}/\d{2})\s+(\d{2}/\d{2})\s+[A-Z0-9]+\s+(.+?)\s+([\d,]+\.\d{2})(?=\n|$)",re.I)
    for match in wf_pattern.finditer(text):
        trans_date,_,desc,amount_s=match.groups(); desc=re.sub(r"\s+"," ",desc).strip()
        if any(x in desc.upper() for x in ["TOTAL ","PURCHASES 23","CASH ADVANCES 29"]): continue
        try: txn_date=datetime.strptime(f"{trans_date}/{year}","%m/%d/%Y").date()
        except ValueError: continue
        amount=float(amount_s.replace(",","")); info=classify_description(db,desc)
        if "PAYMENT" in desc.upper() and "THANK YOU" in desc.upper():
            cat,sub=_category_ids(db,"Transfer"); info.update(type="transfer",category_id=cat,subcategory_id=sub,confidence=.99)
        key=f"{txn_date.isoformat()}|{desc.upper()}|{amount:.2f}|{info['type']}"; occurrence[key]+=1
        rows.append({"date":txn_date.isoformat(),"merchant":info["merchant"],"description":desc,"amount":amount,"type":info["type"],"category_id":info["category_id"],"subcategory_id":info["subcategory_id"],"confidence":info["confidence"],"reason":info["reason"],"is_refund":False,"dedupe_marker":f"occ={occurrence[key]}"})

    parser="known statement layout" if rows else "layout-aware PDF table reconstruction"
    if not rows:
        rows=_layout_pdf_rows(db,path,text,year,statement_type)
    if not rows:
        parser="flexible PDF pattern detection"
        rows=_generic_pdf_rows(db,text,year,statement_type)

    acct_id=None; acct_conf=0.; acct_reason="account could not be identified confidently"
    if last4:
        acct=db.query(Account).filter(Account.last4==last4).first()
        if acct: acct_id,acct_conf,acct_reason=acct.id,.99,"matched statement account ending"
    if not acct_id:
        acct_id,acct_conf,acct_reason=detect_account(db,filename,f"{last4 or ''} {analysis_text[:2200]}",statement_type)
    # For a clearly investment-oriented statement, prefer a single investment account if no explicit match was found.
    if not acct_id and statement_type == "investment":
        investments=db.query(Account).filter(Account.account_type=="investment", Account.active==True).all()
        if len(investments)==1:
            acct_id,acct_conf,acct_reason=investments[0].id,.82,"investment statement matched the only active investment account"

    return {
        "kind":"pdf_statement","rows":rows,"total_rows":len(rows),"suggested_account_id":acct_id,
        "account_confidence":acct_conf,"account_reason":acct_reason,"detected_balance":statement_balance,
        "detected_last4":last4,"detected_product":statement_type.replace("_"," ").title(),
        "statement_type":statement_type,"statement_type_confidence":statement_type_confidence,
        "text_extracted":bool(text.strip()),"pdf_parser":parser,"mapping_required":False,
    }

def create_backup(label: str = "manual") -> Path:
    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    out = backup_dir / f"budget_backup_{stamp}_{label}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        if DB_PATH.exists():
            z.write(DB_PATH, arcname="rhodes_financial.db")
        metadata = {
            "created_at": datetime.now().isoformat(),
            "label": label,
            "app": "Rhodes Financial",
            "version": 1,
        }
        z.writestr("backup_info.json", json.dumps(metadata, indent=2))
    return out


def _review(db: Session, txn: Transaction | None, issue_type: str, message: str):
    db.add(ReviewItem(transaction_id=txn.id if txn else None, issue_type=issue_type, message=message))


def detect_post_import_issues(db: Session, imported_ids: list[int]) -> None:
    imported = db.query(Transaction).filter(Transaction.id.in_(imported_ids)).all() if imported_ids else []
    # Unknown categories / low confidence are marked at import; here detect possible paired transfers and recurring.
    for txn in imported:
        if txn.transaction_type == "transfer":
            other = db.query(Transaction).filter(
                Transaction.id != txn.id,
                Transaction.transaction_type == "transfer",
                Transaction.amount.between(txn.amount - .01, txn.amount + .01),
                Transaction.txn_date.between(txn.txn_date - timedelta(days=3), txn.txn_date + timedelta(days=3)),
                Transaction.account_id != txn.account_id,
            ).first()
            p2p = any(k in txn.raw_description.upper() for k in ["VENMO", "ZELLE", "CASH APP", "PAYPAL"])
            if not other and p2p and txn.txn_date >= date.today() - timedelta(days=180):
                existing = db.query(ReviewItem).join(Transaction, ReviewItem.transaction_id == Transaction.id).filter(
                    ReviewItem.issue_type == "possible_spending_transfer", ReviewItem.status == "open",
                    func.lower(Transaction.merchant) == txn.merchant.lower()
                ).first()
                if not existing:
                    _review(db, txn, "possible_spending_transfer", f"{txn.merchant} is an unmatched person-to-person transfer. Keep it as a transfer, reclassify it as spending, or exclude it?")

    # Recurring candidates by normalized merchant with >= 3 expenses and roughly monthly spacing.
    merchant_groups: dict[str, list[Transaction]] = defaultdict(list)
    all_expenses = db.query(Transaction).filter(Transaction.transaction_type == "expense", Transaction.excluded == False).all()
    for t in all_expenses:
        merchant_groups[t.merchant.lower()].append(t)
    for merchant, txns in merchant_groups.items():
        if len(txns) < 3:
            continue
        txns.sort(key=lambda x: x.txn_date)
        intervals = [(b.txn_date - a.txn_date).days for a, b in zip(txns, txns[1:])]
        if intervals and sum(1 for d in intervals[-4:] if 25 <= d <= 35) >= 2:
            for t in txns[-2:]:
                t.recurring = True
            latest = txns[-1]
            exists = db.query(ReviewItem).filter(ReviewItem.transaction_id == latest.id, ReviewItem.issue_type == "recurring_candidate", ReviewItem.status == "open").first()
            if not exists:
                _review(db, latest, "recurring_candidate", f"{latest.merchant} appears monthly. Mark it as a recurring charge/subscription?")

    # Unusually large expense relative to overall median.
    amounts = [t.amount for t in all_expenses if t.amount > 0]
    if len(amounts) >= 8:
        med = statistics.median(amounts)
        threshold = max(500.0, med * 6)
        for txn in imported:
            if txn.transaction_type == "expense" and txn.amount >= threshold and txn.txn_date >= date.today() - timedelta(days=180):
                exists = db.query(ReviewItem).filter(ReviewItem.transaction_id == txn.id, ReviewItem.issue_type == "large_transaction", ReviewItem.status == "open").first()
                if not exists:
                    _review(db, txn, "large_transaction", f"This ${txn.amount:,.2f} transaction is much larger than your typical expense. Include it in spending analytics?")
    db.commit()


def import_preview_rows(db: Session, preview: dict[str, Any], account_id: int, source_file: str) -> tuple[int, int]:
    if db.query(Transaction).count() > 0:
        create_backup("pre_import")
    account = db.get(Account, account_id)
    if not account:
        raise ValueError("Account not found")
    imported = 0; skipped = 0; imported_ids = []
    for row in preview.get("rows", []):
        txn_date = date.fromisoformat(row["date"])
        desc = row["description"]
        amount = float(row["amount"])
        txn_type = row["type"]
        h = hash_transaction(account_id, txn_date, desc, amount, txn_type, row.get("dedupe_marker", ""))
        if db.query(Transaction).filter(Transaction.original_hash == h).first():
            skipped += 1
            continue
        txn = Transaction(
            account_id=account_id, txn_date=txn_date, merchant=row["merchant"], raw_description=desc,
            amount=amount, transaction_type=txn_type, category_id=row.get("category_id"),
            subcategory_id=row.get("subcategory_id"), reviewed=row.get("confidence", 0) >= .8,
            is_refund=bool(row.get("is_refund", False)), original_hash=h, source_file=source_file,
        )
        db.add(txn); db.flush()
        imported_ids.append(txn.id); imported += 1
        if row.get("confidence", 0) < .8 and txn.txn_date >= date.today() - timedelta(days=180):
            existing_category_review = db.query(ReviewItem).join(Transaction, ReviewItem.transaction_id == Transaction.id).filter(
                ReviewItem.issue_type == "category", ReviewItem.status == "open", func.lower(Transaction.merchant) == txn.merchant.lower()
            ).first()
            if not existing_category_review:
                _review(db, txn, "category", f"Please review how {txn.merchant} should be categorized. Similar transactions can be updated together.")
        if txn.transaction_type == "income":
            txn.income_source = txn.merchant
        if txn.is_refund:
            _review(db, txn, "refund", f"This ${txn.amount:,.2f} credit looks like a refund. Choose the expense category it should reduce, or exclude it if it is not a refund.")
        activity_type = row.get("activity_type")
        if account.account_type == "investment" and activity_type in {"deposit", "withdrawal"}:
            inv_type = "deposit" if activity_type == "deposit" else "withdrawal"
            exists = db.query(InvestmentActivity).filter(
                InvestmentActivity.account_id == account.id,
                InvestmentActivity.activity_date == txn_date,
                InvestmentActivity.activity_type == inv_type,
                InvestmentActivity.amount.between(amount - .01, amount + .01),
            ).first()
            if not exists:
                db.add(InvestmentActivity(account_id=account.id, activity_date=txn_date, activity_type=inv_type, amount=amount, notes=f"Imported from {source_file}: {desc}"))

    if preview.get("detected_balance") is not None:
        account.current_balance = float(preview["detected_balance"])
        db.add(BalanceSnapshot(account_id=account.id, balance=account.current_balance, source="import"))
    if preview.get("detected_last4") and not account.last4:
        account.last4 = preview["detected_last4"]
    db.add(ImportLog(filename=source_file, file_type=Path(source_file).suffix.lower().lstrip("."), account_id=account_id, imported_count=imported, skipped_count=skipped))
    db.commit()
    detect_post_import_issues(db, imported_ids)
    return imported, skipped


def dashboard_period(period: str):
    today = date.today()
    if period == "week":
        start = today - timedelta(days=today.weekday())
        return start, today
    if period == "year":
        return date(today.year, 1, 1), today
    if period == "all":
        return date(1900, 1, 1), today
    return date(today.year, today.month, 1), today


def dashboard_data(db: Session, period: str = "month") -> dict[str, Any]:
    start, end = dashboard_period(period)
    txq = db.query(Transaction).filter(Transaction.txn_date.between(start, end), Transaction.excluded == False)
    expenses = txq.filter(Transaction.transaction_type == "expense").all()
    income = txq.filter(Transaction.transaction_type == "income").all()
    expense_total = sum((-t.amount if t.is_refund else t.amount) for t in expenses)
    income_total = sum(t.amount for t in income)
    savings = income_total - expense_total
    savings_rate = (savings / income_total * 100) if income_total else 0
    cash = sum(a.current_balance for a in db.query(Account).filter(Account.account_type.in_(["checking", "savings"]), Account.active == True).all())
    investments = sum(a.current_balance for a in db.query(Account).filter(Account.account_type == "investment", Account.active == True).all())

    cats = defaultdict(float)
    daily = defaultdict(float)
    for t in expenses:
        signed = -t.amount if t.is_refund else t.amount
        cat_key = (t.category_id, t.category.name if t.category else "Other")
        cats[cat_key] += signed
        daily[t.txn_date.isoformat()] += signed
    top_cats = [
        {"id": key[0], "name": key[1], "amount": amount}
        for key, amount in sorted(cats.items(), key=lambda x: x[1], reverse=True)[:6]
    ]
    daily_points = [{"date": k, "amount": round(v, 2)} for k, v in sorted(daily.items())]
    widgets = json.loads(get_setting(db, "dashboard_widgets", json.dumps(DEFAULT_WIDGETS)))
    return {
        "start": start, "end": end, "period": period, "income": income_total, "expenses": expense_total,
        "savings": savings, "savings_rate": savings_rate, "cash": cash, "investments": investments,
        "top_categories": top_cats, "daily_points": daily_points, "widgets": widgets,
    }



def expenses_month_data(db: Session, year: int, month: int, category_id: int | None = None) -> dict[str, Any]:
    start = date(year, month, 1)
    end = date(year + (month == 12), (month % 12) + 1, 1) - timedelta(days=1)
    base = db.query(Transaction).filter(
        Transaction.txn_date.between(start, end),
        Transaction.transaction_type == "expense",
        Transaction.excluded == False,
    )
    all_expenses = base.order_by(Transaction.txn_date.desc(), Transaction.id.desc()).all()
    visible = [t for t in all_expenses if category_id is None or t.category_id == category_id]

    category_totals = defaultdict(float)
    daily = defaultdict(float)
    for t in all_expenses:
        signed = -t.amount if t.is_refund else t.amount
        category_totals[t.category.name if t.category else "Other"] += signed
        daily[t.txn_date.isoformat()] += signed

    total = sum((-t.amount if t.is_refund else t.amount) for t in all_expenses)
    ordinary_expenses = [t for t in all_expenses if not t.is_refund]
    largest = max((t.amount for t in ordinary_expenses), default=0.0)
    count = len(all_expenses)
    average = total / count if count else 0.0
    filtered_total = sum((-t.amount if t.is_refund else t.amount) for t in visible)
    category_rows = sorted(category_totals.items(), key=lambda x: x[1], reverse=True)
    daily_points = [{"date": d, "amount": round(v, 2)} for d, v in sorted(daily.items())]
    return {
        "start": start, "end": end, "year": year, "month": month,
        "month_value": f"{year:04d}-{month:02d}", "label": start.strftime("%B %Y"),
        "transactions": visible, "total": float(total), "count": count, "average": float(average),
        "largest": float(largest), "filtered_total": float(filtered_total),
        "category_totals": category_rows, "daily_points": daily_points,
    }

def income_month_data(db: Session, year: int, month: int, category_id: int | None = None, subcategory_id: int | None = None) -> dict[str, Any]:
    start = date(year, month, 1)
    end = date(year + (month == 12), (month % 12) + 1, 1) - timedelta(days=1)
    base = db.query(Transaction).filter(
        Transaction.txn_date.between(start, end),
        Transaction.transaction_type == "income",
        Transaction.excluded == False,
        Transaction.is_refund == False,
    )
    all_income = base.order_by(Transaction.txn_date.desc(), Transaction.id.desc()).all()
    visible = [t for t in all_income if (category_id is None or t.category_id == category_id) and (subcategory_id is None or t.subcategory_id == subcategory_id)]
    source_totals = defaultdict(float); daily = defaultdict(float)
    for t in all_income:
        label = t.subcategory.name if t.subcategory else (t.category.name if t.category else (t.income_source or t.merchant or "Other"))
        source_totals[label] += t.amount; daily[t.txn_date.isoformat()] += t.amount
    total=sum(t.amount for t in all_income); count=len(all_income); largest=max((t.amount for t in all_income),default=0.0)
    return {"start":start,"end":end,"year":year,"month":month,"month_value":f"{year:04d}-{month:02d}","label":start.strftime("%B %Y"),"transactions":visible,"total":float(total),"count":count,"average":float(total/count if count else 0),"largest":float(largest),"filtered_total":float(sum(t.amount for t in visible)),"source_totals":sorted(source_totals.items(),key=lambda x:x[1],reverse=True),"daily_points":[{"date":d,"amount":round(v,2)} for d,v in sorted(daily.items())]}


def month_rollover(db: Session, year: int, month: int, budget: Budget) -> float:
    if not budget.rollover:
        return 0.0
    first = date(year, month, 1)
    prev_last = first - timedelta(days=1)
    prev_budget = db.query(Budget).filter(Budget.year == prev_last.year, Budget.month == prev_last.month, Budget.category_id == budget.category_id).first()
    if not prev_budget:
        return 0.0
    spent_rows = db.query(Transaction).filter(
        Transaction.transaction_type == "expense", Transaction.excluded == False,
        Transaction.category_id == budget.category_id,
        func.strftime("%Y", Transaction.txn_date) == f"{prev_last.year:04d}",
        func.strftime("%m", Transaction.txn_date) == f"{prev_last.month:02d}",
    ).all()
    spent = sum((-t.amount if t.is_refund else t.amount) for t in spent_rows)
    return max(0.0, prev_budget.amount - float(spent))


def budget_rows(db: Session, year: int, month: int) -> list[dict[str, Any]]:
    cats = db.query(Category).filter(Category.active == True, ~Category.name.in_(["Income", "Transfer"])).order_by(Category.sort_order).all()
    result = []
    for cat in cats:
        budget = db.query(Budget).filter(Budget.year == year, Budget.month == month, Budget.category_id == cat.id).first()
        spent_rows = db.query(Transaction).filter(
            Transaction.transaction_type == "expense", Transaction.excluded == False, Transaction.category_id == cat.id,
            func.strftime("%Y", Transaction.txn_date) == f"{year:04d}", func.strftime("%m", Transaction.txn_date) == f"{month:02d}",
        ).all()
        spent = sum((-t.amount if t.is_refund else t.amount) for t in spent_rows)
        rollover = month_rollover(db, year, month, budget) if budget else 0
        available = (budget.amount + rollover) if budget else None
        result.append({"category": cat, "budget": budget, "spent": float(spent), "rollover_amount": rollover,
                       "available": available, "remaining": (available - float(spent)) if available is not None else None})
    return result


def report_summary(db: Session, start: date, end: date) -> dict[str, Any]:
    txns = db.query(Transaction).filter(Transaction.txn_date.between(start, end), Transaction.excluded == False).all()
    expenses = [t for t in txns if t.transaction_type == "expense"]
    income = [t for t in txns if t.transaction_type == "income"]
    cat_totals = defaultdict(float)
    merchant_totals = defaultdict(float)
    daily = defaultdict(float)
    for t in expenses:
        signed = -t.amount if t.is_refund else t.amount
        cat_totals[t.category.name if t.category else "Other"] += signed
        merchant_totals[t.merchant] += signed
        daily[t.txn_date.isoformat()] += signed
    exp = sum((-t.amount if t.is_refund else t.amount) for t in expenses); inc = sum(t.amount for t in income)
    return {
        "transactions": txns, "expenses": expenses, "income_rows": income, "expense_total": exp,
        "income_total": inc, "savings": inc-exp, "savings_rate": ((inc-exp)/inc*100 if inc else 0),
        "category_totals": sorted(cat_totals.items(), key=lambda x: x[1], reverse=True),
        "merchant_totals": sorted(merchant_totals.items(), key=lambda x: x[1], reverse=True)[:10],
        "daily": dict(sorted(daily.items())), "start": start, "end": end,
    }


def export_xlsx(db: Session, scope: str, year: int | None = None, month: int | None = None) -> Path:
    today = date.today()
    if scope == "month":
        year = year or today.year; month = month or today.month
        start = date(year, month, 1)
        end = date(year + (month == 12), (month % 12) + 1, 1) - timedelta(days=1)
        filename = f"{start.strftime('%B').lower()}_{str(year)[2:]}.xlsx"
    elif scope == "year":
        year = year or today.year
        start, end = date(year, 1, 1), date(year, 12, 31)
        filename = f"{year}.xlsx"
    else:
        start, end = date(1900, 1, 1), today
        filename = "all_time.xlsx"

    out = DATA_DIR / "exports" / filename
    report = report_summary(db, start, end)
    sections = set(json.loads(get_setting(db, "export_sections", '["summary","transactions","budget","income"]')))
    visuals = set(json.loads(get_setting(db, "export_visuals", '["category","trend","income_vs_expenses","budget_vs_actual","yoy"]')))
    if not sections:
        sections = {"summary"}

    workbook = xlsxwriter.Workbook(out)
    fmt_title = workbook.add_format({"bold": True, "font_size": 18, "font_color": "#FFFFFF", "bg_color": "#111827"})
    fmt_head = workbook.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": "#374151", "border": 1})
    fmt_money = workbook.add_format({"num_format": "$#,##0.00"})
    fmt_pct = workbook.add_format({"num_format": "0.0%"})
    fmt_date = workbook.add_format({"num_format": "mm/dd/yyyy"})
    fmt_note = workbook.add_format({"font_color": "#6B7280", "italic": True})

    summary_sheet = None
    if "summary" in sections or visuals:
        summary_sheet = workbook.add_worksheet("Summary")
        summary_sheet.set_column("A:A", 24); summary_sheet.set_column("B:B", 18)
        summary_sheet.write("A1", "Rhodes Financial", fmt_title)
        summary_sheet.write("A3", "Period", fmt_head); summary_sheet.write("B3", f"{start:%m/%d/%Y} - {end:%m/%d/%Y}")
        metrics = [("Income", report["income_total"]), ("Expenses", report["expense_total"]), ("Savings", report["savings"])]
        for i, (label, value) in enumerate(metrics, 4):
            summary_sheet.write(i-1, 0, label, fmt_head); summary_sheet.write_number(i-1, 1, value, fmt_money)
        summary_sheet.write("A7", "Savings Rate", fmt_head); summary_sheet.write_number("B7", report["savings_rate"] / 100, fmt_pct)
        summary_sheet.write("A9", "Category", fmt_head); summary_sheet.write("B9", "Spending", fmt_head)
        for r, (name, val) in enumerate(report["category_totals"], 9):
            summary_sheet.write(r, 0, name); summary_sheet.write_number(r, 1, val, fmt_money)

        # Hidden helper tables for optional charts.
        helper_col = 7  # H
        summary_sheet.write(0, helper_col, "Date", fmt_head); summary_sheet.write(0, helper_col+1, "Daily spending", fmt_head)
        for r, (d, val) in enumerate(report["daily"].items(), 1):
            summary_sheet.write(r, helper_col, d); summary_sheet.write_number(r, helper_col+1, val)
        summary_sheet.write(0, helper_col+3, "Metric", fmt_head); summary_sheet.write(0, helper_col+4, "Amount", fmt_head)
        summary_sheet.write(1, helper_col+3, "Income"); summary_sheet.write_number(1, helper_col+4, report["income_total"])
        summary_sheet.write(2, helper_col+3, "Expenses"); summary_sheet.write_number(2, helper_col+4, report["expense_total"])

        chart_row = 2
        if "category" in visuals and report["category_totals"]:
            chart = workbook.add_chart({"type": "bar"})
            n = min(len(report["category_totals"]), 10)
            chart.add_series({"name":"Spending by category", "categories":["Summary",9,0,8+n,0], "values":["Summary",9,1,8+n,1]})
            chart.set_title({"name":"Spending by category"}); chart.set_legend({"none":True}); chart.set_style(10)
            summary_sheet.insert_chart(chart_row, 3, chart, {"x_scale":1.05,"y_scale":.95}); chart_row += 16
        if "trend" in visuals and report["daily"]:
            chart = workbook.add_chart({"type":"line"})
            n = len(report["daily"])
            chart.add_series({"name":"Daily spending", "categories":["Summary",1,helper_col,n,helper_col], "values":["Summary",1,helper_col+1,n,helper_col+1]})
            chart.set_title({"name":"Spending trend"}); chart.set_legend({"none":True}); chart.set_style(10)
            summary_sheet.insert_chart(chart_row, 3, chart, {"x_scale":1.05,"y_scale":.95}); chart_row += 16
        if "income_vs_expenses" in visuals:
            chart = workbook.add_chart({"type":"column"})
            chart.add_series({"name":"Amount", "categories":["Summary",1,helper_col+3,2,helper_col+3], "values":["Summary",1,helper_col+4,2,helper_col+4]})
            chart.set_title({"name":"Income vs expenses"}); chart.set_legend({"none":True}); chart.set_style(10)
            summary_sheet.insert_chart(chart_row, 3, chart, {"x_scale":1.05,"y_scale":.95}); chart_row += 16

        if "yoy" in visuals and scope == "month":
            prev_start = date(start.year-1, start.month, 1)
            prev_end = date(prev_start.year + (prev_start.month == 12), (prev_start.month % 12)+1, 1)-timedelta(days=1)
            prev_report = report_summary(db, prev_start, prev_end)
            summary_sheet.write(4, helper_col+3, str(start.year-1)); summary_sheet.write_number(4, helper_col+4, prev_report["expense_total"])
            summary_sheet.write(5, helper_col+3, str(start.year)); summary_sheet.write_number(5, helper_col+4, report["expense_total"])
            chart = workbook.add_chart({"type":"column"})
            chart.add_series({"name":"Expenses", "categories":["Summary",4,helper_col+3,5,helper_col+3], "values":["Summary",4,helper_col+4,5,helper_col+4]})
            chart.set_title({"name":"Year-over-year spending"}); chart.set_legend({"none":True}); chart.set_style(10)
            summary_sheet.insert_chart(chart_row, 3, chart, {"x_scale":1.05,"y_scale":.95}); chart_row += 16
        summary_sheet.set_column(helper_col, helper_col+5, None, None, {"hidden": True})

    if "transactions" in sections:
        wt = workbook.add_worksheet("Transactions")
        headers = ["Date", "Merchant", "Amount", "Type", "Category", "Subcategory", "Account", "Tags", "Notes"]
        for c, h in enumerate(headers): wt.write(0, c, h, fmt_head)
        wt.freeze_panes(1, 0)
        wt.set_column("A:A", 12); wt.set_column("B:B", 30); wt.set_column("C:C", 14); wt.set_column("D:I", 18)
        for r, t in enumerate(sorted(report["transactions"], key=lambda x: x.txn_date), 1):
            wt.write_datetime(r, 0, datetime.combine(t.txn_date, datetime.min.time()), fmt_date)
            wt.write(r, 1, t.merchant); wt.write_number(r, 2, (-t.amount if t.is_refund else t.amount), fmt_money); wt.write(r, 3, t.transaction_type + (" (refund)" if t.is_refund else ""))
            wt.write(r, 4, t.category.name if t.category else ""); wt.write(r, 5, t.subcategory.name if t.subcategory else "")
            wt.write(r, 6, t.account.name if t.account else ""); wt.write(r, 7, ", ".join(tag.name for tag in t.tags)); wt.write(r, 8, t.notes or "")

    if "income" in sections:
        wi = workbook.add_worksheet("Income")
        for c, h in enumerate(["Date", "Source", "Amount", "Category", "Subcategory"]): wi.write(0, c, h, fmt_head)
        wi.set_column("A:A", 12); wi.set_column("B:B", 30); wi.set_column("C:E", 18)
        for r, t in enumerate(sorted(report["income_rows"], key=lambda x: x.txn_date), 1):
            wi.write_datetime(r, 0, datetime.combine(t.txn_date, datetime.min.time()), fmt_date)
            wi.write(r, 1, t.income_source or t.merchant); wi.write_number(r, 2, t.amount, fmt_money)
            wi.write(r, 3, t.category.name if t.category else ""); wi.write(r, 4, t.subcategory.name if t.subcategory else "")

    budget_data = budget_rows(db, year or today.year, month or today.month)
    if "budget" in sections:
        wb = workbook.add_worksheet("Budget")
        for c, h in enumerate(["Category", "Budget", "Rollover", "Available", "Actual", "Remaining"]): wb.write(0, c, h, fmt_head)
        for r, row in enumerate(budget_data, 1):
            wb.write(r, 0, row["category"].name)
            budget_val = row["budget"].amount if row["budget"] else None
            vals = [budget_val, row["rollover_amount"], row["available"], row["spent"], row["remaining"]]
            for c, val in enumerate(vals, 1):
                if val is not None: wb.write_number(r, c, float(val), fmt_money)
        wb.set_column("A:A", 24); wb.set_column("B:F", 14)
        if "budget_vs_actual" in visuals:
            chart = workbook.add_chart({"type":"column"})
            n = len(budget_data)
            if n:
                chart.add_series({"name":"Budget", "categories":["Budget",1,0,n,0], "values":["Budget",1,3,n,3]})
                chart.add_series({"name":"Actual", "categories":["Budget",1,0,n,0], "values":["Budget",1,4,n,4]})
                chart.set_title({"name":"Budget vs actual"}); chart.set_style(10)
                wb.insert_chart(1, 8, chart, {"x_scale":1.15,"y_scale":1.0})
    elif "budget_vs_actual" in visuals and summary_sheet:
        summary_sheet.write(chart_row, 0, "Budget vs actual visual is available when the Budget section is included.", fmt_note)

    workbook.close()
    return out

