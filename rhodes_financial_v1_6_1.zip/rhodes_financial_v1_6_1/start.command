#!/bin/zsh
set -e
cd "$(dirname "$0")"
docker compose up -d --build
sleep 2
open http://localhost:8000
