# v1.6.1

Cleaner Review rows, compact filters, aligned amounts, consistent controls, selected-row highlighting, and contextual bulk controls. Content-based asset versions prevent stale styles after updates. No database schema change.
