#!/bin/zsh
set -e
cd "$(dirname "$0")"
DATA_DIR="$HOME/Documents/Rhodes Financial"
DB="$DATA_DIR/rhodes_financial.db"
BACKUPS="$DATA_DIR/backups"
STAMP=$(date +"%Y-%m-%d_%H%M%S")
mkdir -p "$BACKUPS"
if [ -f "$DB" ]; then
  cp "$DB" "$BACKUPS/pre_update_${STAMP}.db"
  echo "Database safety copy created: $BACKUPS/pre_update_${STAMP}.db"
fi
if docker ps -a --format '{{.Names}}' | grep -qx 'rhodes-financial'; then
  echo "Stopping the existing Rhodes Financial container..."
  docker rm -f rhodes-financial >/dev/null
fi
echo "Building Rhodes Financial v1.6.1..."
docker compose up -d --build
sleep 2
open http://localhost:8000
echo "Update complete. Your database remains at: $DB"
