import hashlib
import json
import os
import re
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, case
from sqlalchemy.orm import Session

from .database import Base, DATA_DIR, engine, get_db, run_migrations
from .models import Account, AccountRelationship, BalanceSnapshot, Budget, Category, InvestmentActivity, MerchantRule, ReviewItem, Setting, Subcategory, Tag, Transaction
from .services import (
    DEFAULT_WIDGETS,
    _review,
    matching_merchant_rule,
    budget_rows,
    create_backup,
    dashboard_data,
    export_xlsx,
    expenses_month_data,
    income_month_data,
    get_setting,
    hash_transaction,
    import_preview_rows,
    init_defaults,
    preview_csv,
    preview_pdf,
    save_import_mapping,
    report_summary,
    reconcile_account_intelligence,
    set_setting,
)

APP_VERSION = "1.6.1"
app = FastAPI(title="Rhodes Financial", version=APP_VERSION)
BASE_DIR = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")
STATIC_REVISIONS = {name: hashlib.sha256((BASE_DIR / "static" / name).read_bytes()).hexdigest()[:12] for name in ("app.css", "app.js")}


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    run_migrations()
    from .database import SessionLocal
    db = SessionLocal()
    try:
        init_defaults(db)
        # Re-evaluate historical transfers after schema upgrades so obvious credit-card
        # payments and owned-account movements benefit from Account Intelligence.
        reconcile_account_intelligence(db)
        cutoff = datetime.now().timestamp() - 86400
        for staged in (DATA_DIR / "imports").glob("*"):
            try:
                if staged.stat().st_mtime < cutoff:
                    staged.unlink(missing_ok=True)
            except OSError:
                pass
    finally:
        db.close()


def common_context(db: Session, request: Request, active: str, **extra):
    review_count = db.query(ReviewItem).filter(ReviewItem.status == "open").count()
    ctx = {"request": request, "active": active, "review_count": review_count, "app_name": "Rhodes Financial", "app_version": APP_VERSION, "static_revisions": STATIC_REVISIONS}
    ctx.update(extra)
    return ctx


def get_categories(db: Session):
    return db.query(Category).filter(Category.active == True).order_by(Category.sort_order, Category.name).all()


def get_accounts(db: Session, include_inactive=False):
    q = db.query(Account)
    if not include_inactive:
        q = q.filter(Account.active == True)
    return q.order_by(Account.account_type, Account.name).all()


def optional_int(value: str | int | None) -> int | None:
    """Convert empty HTML form/query values to None instead of raising a FastAPI 422."""
    if value is None or str(value).strip() == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        raise HTTPException(status_code=422, detail=f"Expected an integer value, got {value!r}")


def optional_float(value: str | float | None) -> float | None:
    """Convert empty HTML form/query values to None instead of raising a FastAPI 422."""
    if value is None or str(value).strip() == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        raise HTTPException(status_code=422, detail=f"Expected a numeric value, got {value!r}")


def normalize_category_pair(db: Session, category_id: int | None, subcategory_id: int | None) -> tuple[int | None, int | None]:
    """Keep category/subcategory pairs consistent even if a stale browser value is submitted."""
    if not category_id:
        return None, None
    category = db.get(Category, category_id)
    if not category or not category.active:
        return None, None
    if not subcategory_id:
        return category_id, None
    sub = db.get(Subcategory, subcategory_id)
    if not sub or not sub.active or sub.category_id != category_id:
        return category_id, None
    return category_id, subcategory_id



def transfer_category_pair(db: Session, subtype: str | None) -> tuple[int | None, int | None]:
    names = {
        "credit_card_payment": "Credit Card Payment", "savings_transfer": "Savings Transfer",
        "investment_contribution": "Investment Contribution", "investment_withdrawal": "Investment Withdrawal",
        "account_transfer": "Account Transfer", "loan_payment": "Loan Payment", "other_transfer": "Other Transfer",
    }
    cat = db.query(Category).filter(Category.name == "Transfer").first()
    if not cat:
        return None, None
    sub = db.query(Subcategory).filter(Subcategory.category_id == cat.id, Subcategory.name == names.get(subtype or "", "Other Transfer")).first()
    return cat.id, (sub.id if sub else None)

def subcategory_map(db: Session) -> dict[str, list[dict[str, object]]]:
    result: dict[str, list[dict[str, object]]] = {}
    for cat in get_categories(db):
        result[str(cat.id)] = [
            {"id": sub.id, "name": sub.name}
            for sub in sorted((s for s in cat.subcategories if s.active), key=lambda s: s.name.lower())
        ]
    return result


def parse_month_value(value: str | None) -> tuple[int, int]:
    today = date.today()
    if value and re.fullmatch(r"\d{4}-\d{2}", value):
        year, month = (int(part) for part in value.split("-"))
        if 1 <= month <= 12 and 2000 <= year <= 2100:
            return year, month
    return today.year, today.month


def safe_return_path(value: str | None, fallback: str = "/transactions") -> str:
    return value if value and value.startswith("/") and not value.startswith("//") else fallback


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, period: str = "month", date_value: str | None = None, db: Session = Depends(get_db)):
    if period not in {"week", "month", "year", "all"}:
        period = "month"
    # Friendly aliases make dashboard links easy to read and preserve historical selections.
    if date_value is None:
        date_value = request.query_params.get("date")
    if period == "month" and date_value and re.fullmatch(r"\d{4}-\d{2}", date_value):
        date_value = date_value + "-01"
    elif period == "year" and date_value and re.fullmatch(r"\d{4}", date_value):
        date_value = date_value + "-01-01"
    data = dashboard_data(db, period, date_value)
    accounts = get_accounts(db)
    return templates.TemplateResponse(
        "dashboard.html",
        common_context(db, request, "dashboard", data=data, accounts=accounts, all_widgets=DEFAULT_WIDGETS),
    )


@app.post("/dashboard/widgets")
def update_dashboard_widgets(widgets: list[str] = Form(default=[]), db: Session = Depends(get_db)):
    allowed = set(DEFAULT_WIDGETS)
    selected = [w for w in widgets if w in allowed]
    set_setting(db, "dashboard_widgets", json.dumps(selected))
    return RedirectResponse(url="/", status_code=303)


@app.get("/transactions", response_class=HTMLResponse)
def transactions_page(
    request: Request,
    start: str | None = None,
    end: str | None = None,
    account_id: str | None = None,
    account_group: str | None = None,
    category_id: str | None = None,
    txn_type: str | None = None,
    recurring: str | None = None,
    refund: str | None = None,
    reviewed: str | None = None,
    expense_class: str | None = None,
    tag: str | None = None,
    search: str | None = None,
    min_amount: str | None = None,
    max_amount: str | None = None,
    page: int = 1,
    db: Session = Depends(get_db),
):
    # Browsers submit blank filter controls as empty query strings. Parse them here
    # instead of letting FastAPI reject ?account_id=&min_amount= with a 422.
    account_id = optional_int(account_id)
    category_id = optional_int(category_id)
    min_amount = optional_float(min_amount)
    max_amount = optional_float(max_amount)

    q = db.query(Transaction).order_by(Transaction.txn_date.desc(), Transaction.id.desc())
    if start:
        q = q.filter(Transaction.txn_date >= date.fromisoformat(start))
    if end:
        q = q.filter(Transaction.txn_date <= date.fromisoformat(end))
    if account_id:
        q = q.filter(Transaction.account_id == account_id)
    if account_group == "cash":
        q = q.filter(Transaction.account.has(Account.account_type.in_(["checking", "savings"])))
    if category_id:
        q = q.filter(Transaction.category_id == category_id)
    if txn_type:
        q = q.filter(Transaction.transaction_type == txn_type)
    if recurring == "yes":
        q = q.filter(Transaction.recurring == True)
    elif recurring == "no":
        q = q.filter(Transaction.recurring == False)
    if refund == "yes":
        q = q.filter(Transaction.is_refund == True)
    elif refund == "no":
        q = q.filter(Transaction.is_refund == False)
    if reviewed == "yes":
        q = q.filter(Transaction.reviewed == True)
    elif reviewed == "no":
        q = q.filter(Transaction.reviewed == False)
    if expense_class:
        q = q.filter(Transaction.expense_class == expense_class)
    if min_amount is not None:
        q = q.filter(Transaction.amount >= min_amount)
    if max_amount is not None:
        q = q.filter(Transaction.amount <= max_amount)
    if search:
        s = f"%{search}%"
        q = q.filter((Transaction.merchant.ilike(s)) | (Transaction.raw_description.ilike(s)) | (Transaction.notes.ilike(s)))
    if tag:
        q = q.filter(Transaction.tags.any(Tag.name.ilike(f"%{tag}%")))
    total_count = q.order_by(None).count()
    page_size = 100
    pages = max(1, (total_count + page_size - 1) // page_size)
    page = min(max(1, page), pages)
    totals = q.order_by(None).with_entities(
        func.sum(case((Transaction.transaction_type == "expense", case((Transaction.is_refund == True, -Transaction.amount), else_=Transaction.amount)), else_=0)),
        func.sum(case((Transaction.transaction_type == "income", Transaction.amount), else_=0)),
    ).filter(Transaction.excluded == False).first()
    txns = q.offset((page - 1) * page_size).limit(page_size).all()
    return templates.TemplateResponse(
        "transactions.html",
        common_context(
            db, request, "transactions", txns=txns, accounts=get_accounts(db), categories=get_categories(db),
            subcategory_map=subcategory_map(db), tags=db.query(Tag).order_by(Tag.name).all(),
            page=page, pages=pages, total_count=total_count,
            first_result=(page-1)*page_size+1 if total_count else 0, last_result=min(page*page_size,total_count),
            previous_url=str(request.url.include_query_params(page=page-1)),
            next_url=str(request.url.include_query_params(page=page+1)),
            filtered_expenses=totals[0] or 0, filtered_income=totals[1] or 0, filters={
                "start": start or "", "end": end or "", "account_id": account_id, "account_group": account_group or "", "category_id": category_id,
                "txn_type": txn_type or "", "recurring": recurring or "", "refund": refund or "", "reviewed": reviewed or "",
                "expense_class": expense_class or "", "tag": tag or "", "search": search or "",
                "min_amount": min_amount if min_amount is not None else "", "max_amount": max_amount if max_amount is not None else "",
            }
        ),
    )


@app.post("/transactions/add")
def add_transaction(
    txn_date: str = Form(...), merchant: str = Form(...), amount: float = Form(...), transaction_type: str = Form(...),
    account_id: int = Form(...), category_id: str | None = Form(None), subcategory_id: str | None = Form(None),
    income_source: str | None = Form(None), notes: str | None = Form(None), tags: str | None = Form(None),
    expense_class: str | None = Form(None), is_refund: bool = Form(False), transfer_subtype: str | None = Form(None), return_to: str = Form("/transactions"), db: Session = Depends(get_db),
):
    category_id = optional_int(category_id)
    subcategory_id = optional_int(subcategory_id)
    category_id, subcategory_id = normalize_category_pair(db, category_id, subcategory_id)
    if transaction_type == "transfer":
        category_id, subcategory_id = transfer_category_pair(db, transfer_subtype)
    d = date.fromisoformat(txn_date)
    h = hash_transaction(account_id, d, f"manual:{merchant}:{uuid.uuid4()}", abs(amount), transaction_type)
    txn = Transaction(
        account_id=account_id, txn_date=d, merchant=merchant.strip(), raw_description=merchant.strip(), amount=abs(amount),
        transaction_type=transaction_type, category_id=category_id, subcategory_id=subcategory_id, income_source=income_source,
        notes=notes, reviewed=True, manual_override=True, original_hash=h, source_file="manual", expense_class=expense_class or None, is_refund=is_refund,
        transfer_subtype=(transfer_subtype or None) if transaction_type == "transfer" else None,
    )
    db.add(txn); db.flush()
    if tags:
        for name in [x.strip() for x in tags.split(",") if x.strip()]:
            tag_obj = db.query(Tag).filter(func.lower(Tag.name) == name.lower()).first()
            if not tag_obj:
                tag_obj = Tag(name=name); db.add(tag_obj); db.flush()
            txn.tags.append(tag_obj)
    db.commit()
    reconcile_account_intelligence(db, [txn.id])
    return RedirectResponse(url=safe_return_path(return_to), status_code=303)


@app.post("/transactions/{txn_id}/edit")
def edit_transaction(
    txn_id: int,
    txn_date: str = Form(...), merchant: str = Form(...), amount: float = Form(...), transaction_type: str = Form(...),
    account_id: int = Form(...), category_id: str | None = Form(None), subcategory_id: str | None = Form(None),
    notes: str | None = Form(None), tags: str | None = Form(None), expense_class: str | None = Form(None),
    recurring: bool = Form(False), subscription: bool = Form(False), is_refund: bool = Form(False), transfer_subtype: str | None = Form(None), apply_scope: str = Form("current"),
    return_to: str = Form("/transactions"), db: Session = Depends(get_db),
):
    category_id = optional_int(category_id)
    subcategory_id = optional_int(subcategory_id)
    category_id, subcategory_id = normalize_category_pair(db, category_id, subcategory_id)
    if transaction_type == "transfer":
        category_id, subcategory_id = transfer_category_pair(db, transfer_subtype)
    txn = db.get(Transaction, txn_id)
    if not txn:
        raise HTTPException(404)
    old_merchant = txn.merchant
    unlink_transfer(db, txn)
    if apply_scope in {"historical", "all"}:
        create_backup("pre_bulk_rule")
        matches = db.query(Transaction).filter(Transaction.merchant == old_merchant, Transaction.transaction_type == txn.transaction_type).all()
        for t in matches:
            unlink_transfer(db, t)
            t.manual_override = True
            t.merchant = merchant.strip()
            t.transaction_type = transaction_type
            t.category_id = category_id
            t.subcategory_id = subcategory_id
            t.expense_class = expense_class or None
            t.transfer_subtype = (transfer_subtype or None) if transaction_type == "transfer" else None
            t.reviewed = True
    txn.txn_date = date.fromisoformat(txn_date)
    txn.merchant = merchant.strip(); txn.amount = abs(amount); txn.transaction_type = transaction_type
    txn.account_id = account_id; txn.category_id = category_id; txn.subcategory_id = subcategory_id
    txn.notes = notes; txn.expense_class = expense_class or None; txn.recurring = recurring; txn.subscription = subscription; txn.is_refund = is_refund
    txn.transfer_subtype = (transfer_subtype or None) if transaction_type == "transfer" else None
    if transaction_type != "transfer":
        txn.linked_transaction_id = None; txn.transfer_match_confidence = None; txn.transfer_match_status = None
    txn.reviewed = True
    txn.manual_override = True
    txn.tags.clear()
    if tags:
        for name in [x.strip() for x in tags.split(",") if x.strip()]:
            tag_obj = db.query(Tag).filter(func.lower(Tag.name) == name.lower()).first()
            if not tag_obj:
                tag_obj = Tag(name=name); db.add(tag_obj); db.flush()
            txn.tags.append(tag_obj)
    if apply_scope == "all":
        rule = db.query(MerchantRule).filter(func.lower(MerchantRule.match_text) == old_merchant.lower()).first()
        if not rule:
            rule = MerchantRule(match_text=old_merchant)
            db.add(rule)
        rule.clean_name = merchant.strip(); rule.transaction_type = transaction_type
        rule.category_id = category_id; rule.subcategory_id = subcategory_id; rule.active = True
    db.query(ReviewItem).filter(ReviewItem.transaction_id == txn.id, ReviewItem.status == "open").update({"status": "resolved"})
    db.commit()
    reconcile_account_intelligence(db, [txn.id])
    return RedirectResponse(url=safe_return_path(return_to), status_code=303)


@app.post("/transactions/{txn_id}/delete")
def delete_transaction(txn_id: int, db: Session = Depends(get_db)):
    txn = db.get(Transaction, txn_id)
    if txn:
        unlink_transfer(db, txn)
        db.delete(txn); db.commit()
    return RedirectResponse(url="/transactions", status_code=303)


@app.get("/expenses", response_class=HTMLResponse)
def expenses_page(
    request: Request, month: str | None = None, category_id: int | None = None, db: Session = Depends(get_db)
):
    year, month_num = parse_month_value(month)
    selected_category = None
    if category_id:
        candidate = db.get(Category, category_id)
        if candidate and candidate.active and candidate.name not in {"Income", "Transfer"}:
            selected_category = candidate
        else:
            category_id = None
    data = expenses_month_data(db, year, month_num, category_id)
    expense_categories = db.query(Category).filter(
        Category.active == True, ~Category.name.in_(["Income", "Transfer"])
    ).order_by(Category.sort_order, Category.name).all()
    totals_by_name = dict(data["category_totals"])
    quick_categories = [c for c in expense_categories if abs(totals_by_name.get(c.name, 0.0)) > 0.0001]
    return templates.TemplateResponse(
        "expenses.html",
        common_context(
            db, request, "expenses", data=data, category_id=category_id, selected_category=selected_category,
            categories=expense_categories, quick_categories=quick_categories, accounts=get_accounts(db),
            subcategory_map=subcategory_map(db),
        ),
    )


@app.get("/income", response_class=HTMLResponse)
def income_page(
    request: Request, month: str | None = None, subcategory_id: int | None = None, db: Session = Depends(get_db)
):
    year, month_num = parse_month_value(month)
    income_cat = db.query(Category).filter(Category.name == "Income", Category.active == True).first()
    selected_subcategory = None
    if subcategory_id and income_cat:
        candidate = db.get(Subcategory, subcategory_id)
        if candidate and candidate.active and candidate.category_id == income_cat.id:
            selected_subcategory = candidate
        else:
            subcategory_id = None
    data = income_month_data(db, year, month_num, income_cat.id if income_cat else None, subcategory_id)
    quick_sources = []
    if income_cat:
        active_subs = db.query(Subcategory).filter(Subcategory.category_id == income_cat.id, Subcategory.active == True).order_by(Subcategory.name).all()
        totals = dict(data["source_totals"])
        quick_sources = [sub for sub in active_subs if abs(totals.get(sub.name, 0.0)) > 0.0001]
    return templates.TemplateResponse(
        "income.html",
        common_context(db, request, "income", data=data, subcategory_id=subcategory_id,
                       selected_subcategory=selected_subcategory, quick_sources=quick_sources),
    )


@app.get("/budget", response_class=HTMLResponse)
def budget_page(request: Request, year: int | None = None, month: int | None = None, db: Session = Depends(get_db)):
    today = date.today(); year = year or today.year; month = month or today.month
    rows = budget_rows(db, year, month)
    return templates.TemplateResponse("budget.html", common_context(db, request, "budget", rows=rows, year=year, month=month))


@app.post("/budget/save")
def save_budget(
    year: int = Form(...), month: int = Form(...), category_id: int = Form(...), amount: str = Form(""), rollover: bool = Form(False),
    db: Session = Depends(get_db),
):
    obj = db.query(Budget).filter(Budget.year == year, Budget.month == month, Budget.category_id == category_id).first()
    if not amount.strip():
        if obj: db.delete(obj)
    else:
        val = max(0.0, float(amount))
        if not obj:
            obj = Budget(year=year, month=month, category_id=category_id, amount=val, rollover=rollover); db.add(obj)
        else:
            obj.amount = val; obj.rollover = rollover
    db.commit()
    return RedirectResponse(url=f"/budget?year={year}&month={month}", status_code=303)


@app.get("/investments", response_class=HTMLResponse)
def investments_page(request: Request, db: Session = Depends(get_db)):
    accounts = db.query(Account).filter(Account.account_type == "investment", Account.active == True).order_by(Account.name).all()
    activities = db.query(InvestmentActivity).order_by(InvestmentActivity.activity_date.desc(), InvestmentActivity.id.desc()).limit(200).all()
    total = sum(a.current_balance for a in accounts)
    return templates.TemplateResponse("investments.html", common_context(db, request, "investments", accounts=accounts, activities=activities, total=total))


@app.post("/accounts/{account_id}/balance")
def update_account_balance(account_id: int, balance: float = Form(...), source: str = Form("manual"), return_to: str = Form("/settings"), db: Session = Depends(get_db)):
    account = db.get(Account, account_id)
    if not account: raise HTTPException(404)
    account.current_balance = balance
    db.add(BalanceSnapshot(account_id=account.id, balance=balance, source=source, balance_date=date.today()))
    db.commit()
    return RedirectResponse(url=return_to, status_code=303)


@app.post("/investments/activity")
def add_investment_activity(
    account_id: int = Form(...), activity_date: str = Form(...), activity_type: str = Form(...), amount: float = Form(...), notes: str | None = Form(None), db: Session = Depends(get_db),
):
    account = db.get(Account, account_id)
    if not account or account.account_type != "investment": raise HTTPException(400)
    db.add(InvestmentActivity(account_id=account_id, activity_date=date.fromisoformat(activity_date), activity_type=activity_type, amount=abs(amount), notes=notes))
    # Deposits/withdrawals can optionally alter tracked account value; for v1 we do so because the user asked for simple cash movements.
    account.current_balance += abs(amount) if activity_type == "deposit" else -abs(amount)
    db.add(BalanceSnapshot(account_id=account.id, balance=account.current_balance, source=f"investment_{activity_type}"))
    db.commit()
    return RedirectResponse(url="/investments", status_code=303)


@app.get("/reports", response_class=HTMLResponse)
def reports_page(request: Request, year: int | None = None, month: int | None = None, db: Session = Depends(get_db)):
    today = date.today(); year = year or today.year; month = month or today.month
    start = date(year, month, 1); end = (date(year + (month == 12), (month % 12) + 1, 1) - timedelta(days=1))
    report = report_summary(db, start, end)
    prev_start = date(year-1, month, 1); prev_end = date(year-1 + (month == 12), (month % 12)+1, 1)-timedelta(days=1)
    prev = report_summary(db, prev_start, prev_end)
    report["prior_year_expense"] = prev["expense_total"]
    # 12-month trend ending in the selected month.
    monthly_trend = []
    cursor_year, cursor_month = year, month
    months = []
    for _ in range(12):
        months.append((cursor_year, cursor_month))
        cursor_month -= 1
        if cursor_month == 0:
            cursor_month = 12; cursor_year -= 1
    for ty, tm in reversed(months):
        ts = date(ty, tm, 1); te = date(ty + (tm == 12), (tm % 12) + 1, 1) - timedelta(days=1)
        tr = report_summary(db, ts, te)
        monthly_trend.append({"label": ts.strftime("%b %y"), "expenses": tr["expense_total"], "savings": tr["savings"]})
    report["monthly_trend"] = monthly_trend
    report["budget_rows"] = budget_rows(db, year, month)
    return templates.TemplateResponse("reports.html", common_context(db, request, "reports", report=report, year=year, month=month))


@app.get("/export/{scope}")
def export_report(scope: str, year: int | None = None, month: int | None = None, db: Session = Depends(get_db)):
    if scope not in {"month", "year", "all"}: raise HTTPException(400)
    path = export_xlsx(db, scope, year, month)
    return FileResponse(path, filename=path.name, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.get("/import", response_class=HTMLResponse)
def import_page(request: Request, db: Session = Depends(get_db)):
    return templates.TemplateResponse("import.html", common_context(db, request, "import", accounts=get_accounts(db)))


@app.post("/import/preview", response_class=HTMLResponse)
async def import_preview(request: Request, file: UploadFile = File(...), db: Session = Depends(get_db)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".csv", ".pdf"}:
        return templates.TemplateResponse("import.html", common_context(db, request, "import", accounts=get_accounts(db), error="Rhodes Financial accepts CSV and PDF files only."), status_code=400)
    token = uuid.uuid4().hex
    raw_path = DATA_DIR / "imports" / f"{token}{suffix}"
    raw_path.write_bytes(await file.read())
    try:
        preview = preview_csv(db, raw_path, file.filename or "upload.csv") if suffix == ".csv" else preview_pdf(db, raw_path, file.filename or "upload.pdf")
        if suffix == ".pdf" and not preview.get("text_extracted", True):
            raise ValueError("No searchable text was found in this PDF. Scanned-image OCR is not enabled in v1.")
        if not preview.get("rows") and not preview.get("mapping_required"):
            detail = "No transactions could be identified."
            if suffix == ".csv":
                detail += f" Columns found: {', '.join(preview.get('headers', [])) or 'none'}."
            else:
                detail += " The PDF may use an unsupported text layout or may be image-only."
            raise ValueError(detail + " Nothing has been imported.")
    except Exception as exc:
        raw_path.unlink(missing_ok=True)
        return templates.TemplateResponse("import.html", common_context(db, request, "import", accounts=get_accounts(db), error=str(exc)), status_code=400)
    preview_file = DATA_DIR / "imports" / f"{token}.json"
    preview_file.write_text(json.dumps({"filename": file.filename, "suffix": suffix, "preview": preview}, default=str))
    cats = get_categories(db)
    subcats = db.query(Subcategory).filter(Subcategory.active == True).all()
    cat_lookup = {c.id: c.name for c in cats}; sub_lookup = {s.id: s.name for s in subcats}
    return templates.TemplateResponse("import_preview.html", common_context(db, request, "import", token=token, preview=preview, accounts=get_accounts(db), filename=file.filename, cat_lookup=cat_lookup, sub_lookup=sub_lookup))


@app.post("/import/remap", response_class=HTMLResponse)
def import_remap(
    request: Request,
    token: str = Form(...),
    date_column: str = Form(...), description_column: str = Form(...), amount_column: str = Form(""),
    debit_column: str = Form(""), credit_column: str = Form(""), balance_column: str = Form(""), type_column: str = Form(""),
    amount_mode: str = Form("negative_expense"), remember_mapping: bool = Form(False),
    db: Session = Depends(get_db),
):
    json_path = DATA_DIR / "imports" / f"{token}.json"
    if not json_path.exists(): raise HTTPException(404, "Import preview expired")
    payload = json.loads(json_path.read_text())
    raw_path = DATA_DIR / "imports" / f"{token}{payload['suffix']}"
    if payload["suffix"] != ".csv": raise HTTPException(400, "Column mapping is only used for CSV imports")
    mapping = {
        "date": date_column or None, "description": description_column or None,
        "amount": amount_column or None, "debit": debit_column or None, "credit": credit_column or None,
        "balance": balance_column or None, "type": type_column or None,
    }
    if not mapping["amount"] and not (mapping["debit"] or mapping["credit"]):
        return templates.TemplateResponse("import.html", common_context(db, request, "import", accounts=get_accounts(db), error="Choose an Amount column or at least one Debit/Credit column."), status_code=400)
    preview = preview_csv(db, raw_path, payload.get("filename") or "upload.csv", mapping_override=mapping, amount_mode=amount_mode)
    if not preview.get("rows"):
        return templates.TemplateResponse("import.html", common_context(db, request, "import", accounts=get_accounts(db), error="The selected columns did not produce any valid transactions. Nothing has been imported."), status_code=400)
    if remember_mapping:
        save_import_mapping(db, preview.get("headers", []), {**mapping, "amount_mode": amount_mode})
    payload["preview"] = preview
    json_path.write_text(json.dumps(payload, default=str))
    cats=get_categories(db); subcats=db.query(Subcategory).filter(Subcategory.active == True).all()
    return templates.TemplateResponse("import_preview.html", common_context(db, request, "import", token=token, preview=preview, accounts=get_accounts(db), filename=payload.get("filename"), cat_lookup={c.id:c.name for c in cats}, sub_lookup={x.id:x.name for x in subcats}))


@app.post("/import/confirm")
def import_confirm(
    token: str = Form(...), account_id: int = Form(...),
    export_sections: list[str] = Form(default=[]), export_visuals: list[str] = Form(default=[]),
    balance_date: str = Form(""),
    db: Session = Depends(get_db)
):
    json_path = DATA_DIR / "imports" / f"{token}.json"
    if not json_path.exists(): raise HTTPException(404, "Import preview expired")
    payload = json.loads(json_path.read_text())
    raw_path = DATA_DIR / "imports" / f"{token}{payload['suffix']}"
    set_setting(db, "export_sections", json.dumps(export_sections or ["summary", "transactions", "budget", "income"]))
    set_setting(db, "export_visuals", json.dumps(export_visuals))
    if balance_date:
        try:
            payload["preview"]["detected_balance_date"] = date.fromisoformat(balance_date).isoformat()
        except ValueError:
            raise HTTPException(422, "Enter a valid balance date")
    imported, skipped = import_preview_rows(db, payload["preview"], account_id, payload["filename"] or raw_path.name)
    raw_path.unlink(missing_ok=True); json_path.unlink(missing_ok=True)
    return RedirectResponse(url=f"/review?imported={imported}&skipped={skipped}", status_code=303)


@app.get("/import/cancel/{token}")
def import_cancel(token: str):
    for path in (DATA_DIR / "imports").glob(f"{token}*"):
        path.unlink(missing_ok=True)
    return RedirectResponse(url="/import", status_code=303)

@app.get("/review", response_class=HTMLResponse)
def review_page(request: Request, imported: int | None = None, skipped: int | None = None, db: Session = Depends(get_db)):
    items = db.query(ReviewItem).filter(ReviewItem.status == "open").order_by(ReviewItem.created_at.desc()).all()
    labels = {
        "category": ("Choose a category", "We aren't sure where these belong."),
        "refund": ("Is this a refund?", "Confirm how this credit should be handled."),
        "unmatched_transfer": ("Where did this money go?", "We think this moved between your accounts, but couldn't find the other side yet."),
        "credit_card_payment": ("Is this a credit card payment?", "Confirm the card payment so it won't count as spending."),
        "possible_spending_transfer": ("Transfer or spending?", "This person-to-person payment could be either."),
        "recurring_candidate": ("Does this repeat?", "This looks like something you pay regularly."),
        "large_transaction": ("Include this transaction?", "This is much larger than your usual spending."),
    }
    grouped = {}
    for item in items:
        txn = item.transaction
        merchant_key = (txn.merchant.lower().strip() if txn and txn.merchant else "")
        # Group category/recurring decisions by merchant. Keep transfer/refund decisions separate by amount/account.
        if item.issue_type in {"category", "recurring_candidate"}:
            key = (item.issue_type, merchant_key, txn.transaction_type if txn else "")
        else:
            key = (item.issue_type, item.id)
        if key not in grouped:
            title, help_text = labels.get(item.issue_type, ("Check this transaction", "Rhodes Financial needs a quick decision."))
            grouped[key] = {"title": title, "help": help_text, "issue_type": item.issue_type, "items": [], "merchant": txn.merchant if txn else ""}
        grouped[key]["items"].append(item)
    groups = list(grouped.values())
    for group in groups:
        transactions = {item.transaction.id: item.transaction for item in group["items"] if item.transaction}
        group["total"] = sum(txn.amount for txn in transactions.values())
        group["count"] = len(transactions)
        group["tab"] = "categories" if group["issue_type"] == "category" else "transfers" if group["issue_type"] in {"unmatched_transfer", "credit_card_payment", "possible_spending_transfer"} else "other"
    waiting = db.query(ReviewItem).join(Transaction).filter(ReviewItem.status == "waiting",
        Transaction.transaction_type == "transfer", Transaction.excluded == False,
        Transaction.linked_transaction_id == None).order_by(Transaction.txn_date.desc()).all()
    summary = {}
    for g in groups:
        summary[g["issue_type"]] = summary.get(g["issue_type"], 0) + len(g["items"])
    return templates.TemplateResponse("review.html", common_context(db, request, "review", groups=groups, waiting=waiting, summary=summary, imported=imported, skipped=skipped, categories=get_categories(db), subcategory_map=subcategory_map(db), accounts=get_accounts(db)))


def unlink_transfer(db: Session, txn: Transaction):
    if txn.linked_transaction_id:
        other = db.get(Transaction, txn.linked_transaction_id)
        if other and other.linked_transaction_id == txn.id:
            other.linked_transaction_id = None
            other.transfer_match_confidence = None
            other.transfer_match_status = "unmatched" if other.transaction_type == "transfer" else None
    txn.linked_transaction_id = None
    txn.transfer_match_confidence = None
    txn.transfer_match_status = None


def _apply_review_action(db: Session, item: ReviewItem, action: str, transfer_subtype: str | None = None):
    allowed = {"exclude", "keep", "confirm", "expense", "not_transfer", "recurring", "subscription", "transfer", "credit_card_payment", "dismiss", "not_refund"}
    if action not in allowed:
        raise HTTPException(422, "Unknown review action")
    txn = item.transaction
    if txn and action != "dismiss":
        txn.reviewed = True
        if action == "exclude":
            unlink_transfer(db, txn)
            txn.excluded = True
        elif action in {"expense", "not_transfer"}:
            unlink_transfer(db, txn)
            txn.manual_override = True
            txn.transaction_type = "expense"
            txn.transfer_subtype = None
            txn.category_id = txn.subcategory_id = None
            _review(db, txn, "category", "Choose an expense category for this transaction.")
        elif action in {"confirm", "not_refund"} and item.issue_type == "refund":
            unlink_transfer(db, txn)
            txn.manual_override = True
            txn.is_refund = action == "confirm"
            txn.transaction_type = "expense" if txn.is_refund else "income"
            txn.transfer_subtype = None
            if txn.is_refund:
                txn.category_id = txn.subcategory_id = None
                _review(db, txn, "category", "Choose the expense category this refund reduces.")
            else:
                income = db.query(Category).filter(Category.name == "Income").first()
                txn.category_id = income.id if income else None
                txn.subcategory_id = None
        elif action == "recurring": txn.recurring = True
        elif action == "subscription": txn.recurring = True; txn.subscription = True
        elif action in {"transfer", "credit_card_payment"}:
            txn.manual_override = True
            txn.transaction_type = "transfer"
            txn.is_refund = False
            txn.transfer_subtype = transfer_subtype or ("credit_card_payment" if action == "credit_card_payment" else txn.transfer_subtype or "account_transfer")
            txn.category_id, txn.subcategory_id = transfer_category_pair(db, txn.transfer_subtype)
        elif action in {"keep", "confirm"}: txn.excluded = False
    item.status = "dismissed" if action == "dismiss" else "resolved"


def categorize_review_transactions(db: Session, transactions: list[Transaction], category_id: int | None,
                                   subcategory_id: int | None, remember_rule: bool):
    cid, sid = normalize_category_pair(db, category_id, subcategory_id)
    if not cid:
        raise HTTPException(422, "Choose an active category")
    cat = db.get(Category, cid)
    expected_type = "transfer" if cat.name == "Transfer" else "income" if cat.name == "Income" else "expense"
    if any(txn.transaction_type != expected_type for txn in transactions):
        raise HTTPException(422, "Select transactions of the same type as the category")
    for txn in transactions:
        txn.category_id = cid; txn.subcategory_id = sid
        txn.manual_override = True; txn.reviewed = True
        db.query(ReviewItem).filter(ReviewItem.transaction_id == txn.id, ReviewItem.issue_type == "category",
            ReviewItem.status == "open").update({"status": "resolved"}, synchronize_session=False)
        if remember_rule:
            rule = db.query(MerchantRule).filter(func.lower(MerchantRule.match_text) == txn.merchant.lower()).first()
            if not rule:
                rule = MerchantRule(match_text=txn.merchant)
                db.add(rule); db.flush()
            rule.clean_name = txn.merchant; rule.transaction_type = txn.transaction_type
            rule.category_id = cid; rule.subcategory_id = sid; rule.active = True


@app.post("/review/{item_id:int}/action")
def review_action(item_id: int, action: str = Form(...), transfer_subtype: str | None = Form(None), category_id: str | None = Form(None), subcategory_id: str | None = Form(None), apply_similar: bool = Form(False), remember_rule: bool = Form(False), db: Session = Depends(get_db)):
    item = db.get(ReviewItem, item_id)
    if not item: raise HTTPException(404)
    if item.status not in {"open", "waiting"}:
        return RedirectResponse(url="/review", status_code=303)
    if apply_similar and item.issue_type not in {"category", "recurring_candidate"}:
        raise HTTPException(422, "This decision must be made individually")
    if action == "categorize":
        if not item.transaction: raise HTTPException(422, "Transaction is missing")
        cid, sid = normalize_category_pair(db, optional_int(category_id), optional_int(subcategory_id))
        if cid is None: raise HTTPException(422, "Choose an active category")
        original = item.transaction
        cat = db.get(Category, cid)
        expected_type = "transfer" if cat.name == "Transfer" else "income" if cat.name == "Income" else "expense"
        if expected_type != original.transaction_type:
            raise HTTPException(422, "Choose a category matching the transaction type; use Change details to change its type")
        targets = [original]
        if apply_similar:
            targets = db.query(Transaction).filter(func.lower(Transaction.merchant) == original.merchant.lower(), Transaction.transaction_type == original.transaction_type, Transaction.excluded == False).all()
        categorize_review_transactions(db, targets, cid, sid, remember_rule)
        item.status = "resolved"
    else:
        targets = [item]
        if apply_similar and item.transaction:
            targets = db.query(ReviewItem).join(Transaction).filter(ReviewItem.status == "open", ReviewItem.issue_type == item.issue_type, func.lower(Transaction.merchant) == item.transaction.merchant.lower(), Transaction.transaction_type == item.transaction.transaction_type).all()
        for target in targets:
            _apply_review_action(db, target, action, transfer_subtype)
            if action in {"recurring", "subscription"} and target.transaction and remember_rule:
                txn = target.transaction
                rule = db.query(MerchantRule).filter(func.lower(MerchantRule.match_text) == txn.merchant.lower()).first()
                if not rule:
                    rule = MerchantRule(match_text=txn.merchant); db.add(rule); db.flush()
                rule.clean_name = txn.merchant; rule.transaction_type = txn.transaction_type
                rule.category_id = txn.category_id; rule.subcategory_id = txn.subcategory_id
                rule.recurring = True; rule.subscription = action == "subscription"
                rule.active = True
    db.commit()
    reconcile_account_intelligence(db)
    return RedirectResponse(url="/review", status_code=303)


@app.post("/review/bulk/action")
def review_bulk_action(item_ids: list[int] = Form(default=[]), action: str = Form(...),
    category_id: str | None = Form(None), subcategory_id: str | None = Form(None),
    remember_rule: bool = Form(False), db: Session = Depends(get_db)):
    allowed = {"categorize", "dismiss"}
    if action not in allowed:
        raise HTTPException(422, "Bulk changes support category decisions or dismissal")
    items = db.query(ReviewItem).filter(ReviewItem.id.in_(item_ids), ReviewItem.status == "open").all() if item_ids else []
    if not items:
        raise HTTPException(422, "Select at least one open decision")
    if action == "categorize":
        if any(item.issue_type != "category" or not item.transaction for item in items):
            raise HTTPException(422, "Select category decisions only")
        transactions = list({item.transaction.id: item.transaction for item in items}.values())
        categorize_review_transactions(db, transactions, optional_int(category_id), optional_int(subcategory_id), remember_rule)
    else:
        for item in items:
            _apply_review_action(db, item, action)
    db.commit()
    reconcile_account_intelligence(db)
    return RedirectResponse(url="/review", status_code=303)


@app.get("/settings", response_class=HTMLResponse)
def settings_page(request: Request, db: Session = Depends(get_db)):
    return templates.TemplateResponse("settings.html", common_context(
        db, request, "settings", accounts=get_accounts(db, True), categories=get_categories(db),
        subcategories=db.query(Subcategory).order_by(Subcategory.category_id, Subcategory.name).all(),
        rules=db.query(MerchantRule).order_by(MerchantRule.match_text).all(),
        relationships=db.query(AccountRelationship).order_by(AccountRelationship.relationship_type, AccountRelationship.id).all(),
        ai_enabled=get_setting(db, "ai_enabled", "false") == "true",
    ))


@app.post("/settings/account")
def save_account(
    account_id: str | None = Form(None), name: str = Form(...), account_type: str = Form(...), last4: str | None = Form(None),
    institution: str | None = Form(None), product_name: str | None = Form(None), active: bool = Form(False), db: Session = Depends(get_db),
):
    account_id = optional_int(account_id)
    if account_id:
        obj = db.get(Account, account_id)
        if not obj: raise HTTPException(404)
        obj.name = name.strip(); obj.account_type = account_type; obj.last4 = (last4 or "").strip()[-4:] or None
        obj.institution = (institution or "").strip() or None; obj.product_name = (product_name or "").strip() or None; obj.active = active
    else:
        obj = Account(name=name.strip(), account_type=account_type, last4=(last4 or "").strip()[-4:] or None,
                      institution=(institution or "").strip() or None, product_name=(product_name or "").strip() or None, active=True)
        db.add(obj)
    db.commit()
    return RedirectResponse(url="/settings", status_code=303)


@app.post("/settings/relationship")
def save_relationship(
    source_account_id: int = Form(...), target_account_id: int = Form(...), relationship_type: str = Form(...), db: Session = Depends(get_db),
):
    if source_account_id == target_account_id:
        return RedirectResponse(url="/settings?relationship_error=same", status_code=303)
    allowed = {"account_transfer", "credit_card_payment", "savings_transfer", "investment_contribution", "investment_withdrawal"}
    if relationship_type not in allowed:
        raise HTTPException(422, "Unknown relationship type")
    rel = db.query(AccountRelationship).filter(
        AccountRelationship.source_account_id == source_account_id,
        AccountRelationship.target_account_id == target_account_id,
        AccountRelationship.relationship_type == relationship_type,
    ).first()
    if not rel:
        rel = AccountRelationship(source_account_id=source_account_id, target_account_id=target_account_id, relationship_type=relationship_type, confidence=1.0, confirmed=True)
        db.add(rel)
    else:
        rel.confirmed = True; rel.confidence = 1.0
    db.commit()
    reconcile_account_intelligence(db)
    return RedirectResponse(url="/settings", status_code=303)


@app.post("/settings/relationship/{relationship_id}/delete")
def delete_relationship(relationship_id: int, db: Session = Depends(get_db)):
    rel = db.get(AccountRelationship, relationship_id)
    if rel:
        db.delete(rel); db.commit()
    return RedirectResponse(url="/settings", status_code=303)


@app.post("/settings/reconcile")
def reconcile_all_accounts(db: Session = Depends(get_db)):
    reconcile_account_intelligence(db)
    return RedirectResponse(url="/settings?reconciled=1", status_code=303)


@app.post("/settings/category")
def save_category(category_id: str | None = Form(None), name: str = Form(...), subcategories: str = Form(""), db: Session = Depends(get_db)):
    category_id = optional_int(category_id)
    if category_id:
        cat = db.get(Category, category_id)
        if not cat: raise HTTPException(404)
        cat.name = name.strip()
        existing = {s.name.lower(): s for s in cat.subcategories}
    else:
        cat = Category(name=name.strip(), sort_order=(db.query(func.max(Category.sort_order)).scalar() or 0) + 1); db.add(cat); db.flush(); existing = {}
    desired = [x.strip() for x in subcategories.split(",") if x.strip()]
    desired_lower = {x.lower() for x in desired}
    for s in cat.subcategories:
        s.active = s.name.lower() in desired_lower
    for sname in desired:
        if sname.lower() not in existing:
            db.add(Subcategory(category_id=cat.id, name=sname, active=True))
        else:
            existing[sname.lower()].active = True
    db.commit()
    return RedirectResponse(url="/settings", status_code=303)


@app.post("/settings/backup")
def manual_backup():
    create_backup("manual")
    return RedirectResponse(url="/settings?backup=1", status_code=303)


@app.post("/settings/ai")
def ai_settings(enabled: bool = Form(False), db: Session = Depends(get_db)):
    set_setting(db, "ai_enabled", "true" if enabled else "false")
    return RedirectResponse(url="/settings", status_code=303)


@app.get("/health")
def health():
    return {"status": "ok", "app": "Rhodes Financial", "version": APP_VERSION, "data_dir": str(DATA_DIR)}
