#!/bin/zsh
set -e
cd "$(dirname "$0")"
docker stop rhodes-financial
echo "Rhodes Financial stopped."
