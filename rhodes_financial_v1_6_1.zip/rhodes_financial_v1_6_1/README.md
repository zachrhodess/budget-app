# Rhodes Financial v1.6.1

Complete standalone application package recovered from the installed v1.6.1 app.

1. Open Docker Desktop and wait for it to start.
2. Extract this ZIP.
3. Double-click update.command to rebuild and launch the app.

No previous source folder is required. Your existing database stays in Documents/Rhodes Financial. The updater creates a safety copy before updating. Use start.command to start and stop.command to stop the app.

Open http://localhost:8000 in your browser. This package includes all application source and dependencies; it contains no personal financial data.

v1.6.1 includes the refined Review inbox, contextual bulk controls, selected-row highlighting, and content-versioned stylesheets and scripts.
