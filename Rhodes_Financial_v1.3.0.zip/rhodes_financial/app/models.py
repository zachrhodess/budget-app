from datetime import date, datetime

from sqlalchemy import Boolean, Column, Date, DateTime, Float, ForeignKey, Integer, String, Table, Text, UniqueConstraint
from sqlalchemy.orm import relationship

from .database import Base

transaction_tags = Table(
    "transaction_tags",
    Base.metadata,
    Column("transaction_id", ForeignKey("transactions.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
)


class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False, unique=True)
    account_type = Column(String(30), nullable=False)  # checking, savings, credit, investment
    current_balance = Column(Float, default=0.0)
    last4 = Column(String(4), nullable=True)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    transactions = relationship("Transaction", back_populates="account")
    snapshots = relationship("BalanceSnapshot", back_populates="account", cascade="all, delete-orphan")


class BalanceSnapshot(Base):
    __tablename__ = "balance_snapshots"
    id = Column(Integer, primary_key=True)
    account_id = Column(Integer, ForeignKey("accounts.id", ondelete="CASCADE"), nullable=False)
    balance = Column(Float, nullable=False)
    captured_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    source = Column(String(30), default="manual")
    account = relationship("Account", back_populates="snapshots")


class Category(Base):
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True)
    name = Column(String(80), nullable=False, unique=True)
    active = Column(Boolean, default=True)
    sort_order = Column(Integer, default=0)
    subcategories = relationship("Subcategory", back_populates="category", cascade="all, delete-orphan")


class Subcategory(Base):
    __tablename__ = "subcategories"
    __table_args__ = (UniqueConstraint("category_id", "name", name="uq_subcategory"),)
    id = Column(Integer, primary_key=True)
    category_id = Column(Integer, ForeignKey("categories.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(80), nullable=False)
    active = Column(Boolean, default=True)
    category = relationship("Category", back_populates="subcategories")


class Tag(Base):
    __tablename__ = "tags"
    id = Column(Integer, primary_key=True)
    name = Column(String(80), unique=True, nullable=False)


class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True)
    account_id = Column(Integer, ForeignKey("accounts.id", ondelete="CASCADE"), nullable=False)
    txn_date = Column(Date, nullable=False, index=True)
    merchant = Column(String(180), nullable=False)
    raw_description = Column(Text, nullable=False)
    amount = Column(Float, nullable=False)  # positive absolute amount
    transaction_type = Column(String(20), nullable=False)  # expense, income, transfer
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=True)
    subcategory_id = Column(Integer, ForeignKey("subcategories.id"), nullable=True)
    income_source = Column(String(120), nullable=True)
    notes = Column(Text, nullable=True)
    reviewed = Column(Boolean, default=False)
    excluded = Column(Boolean, default=False)
    recurring = Column(Boolean, default=False)
    subscription = Column(Boolean, default=False)
    is_refund = Column(Boolean, default=False)
    expense_class = Column(String(20), nullable=True)  # fixed, variable, discretionary
    original_hash = Column(String(64), nullable=False, index=True)
    source_file = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    account = relationship("Account", back_populates="transactions")
    category = relationship("Category")
    subcategory = relationship("Subcategory")
    tags = relationship("Tag", secondary=transaction_tags)
    review_items = relationship("ReviewItem", back_populates="transaction", cascade="all, delete-orphan")


class MerchantRule(Base):
    __tablename__ = "merchant_rules"
    id = Column(Integer, primary_key=True)
    match_text = Column(String(180), nullable=False, unique=True)
    clean_name = Column(String(180), nullable=True)
    transaction_type = Column(String(20), nullable=True)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=True)
    subcategory_id = Column(Integer, ForeignKey("subcategories.id"), nullable=True)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Budget(Base):
    __tablename__ = "budgets"
    __table_args__ = (UniqueConstraint("year", "month", "category_id", name="uq_budget_month_category"),)
    id = Column(Integer, primary_key=True)
    year = Column(Integer, nullable=False)
    month = Column(Integer, nullable=False)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    amount = Column(Float, nullable=False)
    rollover = Column(Boolean, default=False)
    category = relationship("Category")


class ReviewItem(Base):
    __tablename__ = "review_items"
    id = Column(Integer, primary_key=True)
    transaction_id = Column(Integer, ForeignKey("transactions.id", ondelete="CASCADE"), nullable=True)
    issue_type = Column(String(50), nullable=False)
    message = Column(Text, nullable=False)
    status = Column(String(20), default="open")  # open, resolved, dismissed
    created_at = Column(DateTime, default=datetime.utcnow)
    transaction = relationship("Transaction", back_populates="review_items")


class ImportLog(Base):
    __tablename__ = "import_logs"
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    file_type = Column(String(10), nullable=False)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=True)
    imported_count = Column(Integer, default=0)
    skipped_count = Column(Integer, default=0)
    imported_at = Column(DateTime, default=datetime.utcnow)


class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(80), primary_key=True)
    value = Column(Text, nullable=False)


class InvestmentActivity(Base):
    __tablename__ = "investment_activity"
    id = Column(Integer, primary_key=True)
    account_id = Column(Integer, ForeignKey("accounts.id", ondelete="CASCADE"), nullable=False)
    activity_date = Column(Date, default=date.today, nullable=False)
    activity_type = Column(String(20), nullable=False)  # deposit, withdrawal
    amount = Column(Float, nullable=False)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    account = relationship("Account")
