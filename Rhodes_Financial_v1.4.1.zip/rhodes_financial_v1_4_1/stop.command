#!/bin/zsh
set -e
cd "$(dirname "$0")"
echo "Stopping Rhodes Financial..."
docker compose down
echo "Stopped. Your data remains in ~/Documents/Rhodes Financial/"
