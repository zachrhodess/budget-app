# Rhodes Financial v1.4.1

## Review + Transfer Intelligence + Dashboard Date Navigation

v1.4.1 is a usability patch built on v1.4 Account Intelligence.

### Faster, simpler Review page
- Renamed the user-facing "Needs Review" workflow to **Review**.
- Reworded review prompts in plain English, such as "Is this a credit card payment?", "Where did this money go?", and "Choose a category".
- Similar category and recurring items are grouped by merchant instead of forcing one-at-a-time review.
- Grouped decisions include **Apply to all** so one correction can resolve similar open items.
- Category review now includes category/subcategory selectors directly on the Review card.
- Review cards show only the useful context: merchant, date, amount, account, current category, and the decision being requested.
- High-confidence imports continue to bypass Review automatically; Review stays focused on uncertain or accounting-important items.

### Transfer subcategories
The existing **Transfer** top-level category now contains:
- Credit Card Payment
- Savings Transfer
- Investment Contribution
- Investment Withdrawal
- Account Transfer
- Loan Payment
- Other Transfer

Transaction recognition assigns these subcategories automatically when it can identify the transfer type. Existing v1.4 transfer intelligence also updates recognized historical transfers during reconciliation.

### Credit-card payments
- Recognized credit-card payments are stored as `Transfer → Credit Card Payment`.
- They remain excluded from expense/income totals.
- Matching opposite-side card payments can still be linked across owned accounts.
- Manual transaction editing/creation now keeps the Transfer category/subcategory synchronized with the selected transfer kind.

### Dashboard historical dates
The dashboard can now display a specific historical period instead of only the current one.
- **Week:** choose a date/week or move backward/forward one week.
- **Month:** choose a month or move backward/forward one month.
- **Year:** choose a year or move backward/forward one year.
- **All time:** unchanged.
- Income, expenses, category links, charts, and report links use the selected dashboard period.
- The selected period is preserved in the dashboard URL.

## Compatibility

This release uses schema migration 4. Existing databases are upgraded in place and existing transactions are preserved. `update.command` makes a safety copy of the SQLite database before rebuilding the app.

Existing users should run `update.command` from the v1.4.1 folder.
