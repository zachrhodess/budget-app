"""Optional local-AI integration boundary.

Version 1 deliberately does not call any AI service. Future Ollama support can be
implemented here without exposing the database layer directly to a model.
Suggested pattern:
1. Query only the minimum transaction fields needed for a question.
2. Send them to localhost Ollama.
3. Return a proposed answer or proposed changes.
4. Require explicit user approval before database writes.
"""

from dataclasses import dataclass


@dataclass
class AIProposal:
    summary: str
    changes: list[dict]


class LocalAIProvider:
    enabled = False

    def analyze(self, prompt: str, context: list[dict]) -> AIProposal:
        raise RuntimeError("Local AI is not enabled in Rhodes Financial v1.")
