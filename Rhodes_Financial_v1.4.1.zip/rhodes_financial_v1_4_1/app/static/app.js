function openModal(id){document.getElementById(id)?.classList.add('open')}
function closeModal(id){document.getElementById(id)?.classList.remove('open')}
document.addEventListener('click',e=>{if(e.target.classList.contains('modal'))e.target.classList.remove('open')})
function showFileName(input){document.getElementById('fileName').textContent=input.files?.[0]?.name||'Select a file'}
function money(v){return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(v||0)}

function drawLineChart(canvasId,labels,values,emptyId){
 const c=document.getElementById(canvasId); if(!c)return; const empty=document.getElementById(emptyId);
 if(!values||!values.length){c.classList.add('hidden');empty?.classList.remove('hidden');return}
 const dpr=window.devicePixelRatio||1; const rect=c.getBoundingClientRect(); const w=Math.max(rect.width,500),h=240;c.width=w*dpr;c.height=h*dpr;c.style.height=h+'px';
 const x=c.getContext('2d');x.scale(dpr,dpr);const pad={l:46,r:18,t:15,b:30};const pw=w-pad.l-pad.r,ph=h-pad.t-pad.b;const max=Math.max(...values,1);const stepY=max/4;
 x.clearRect(0,0,w,h);x.font='11px system-ui';x.fillStyle='#7f91a7';x.strokeStyle='#223149';x.lineWidth=1;
 for(let i=0;i<=4;i++){const y=pad.t+ph-(i/4)*ph;x.beginPath();x.moveTo(pad.l,y);x.lineTo(w-pad.r,y);x.stroke();x.fillText('$'+Math.round(stepY*i),4,y+4)}
 const pts=values.map((v,i)=>({x:pad.l+(values.length===1?pw/2:(i/(values.length-1))*pw),y:pad.t+ph-(v/max)*ph}));
 const grad=x.createLinearGradient(0,pad.t,0,pad.t+ph);grad.addColorStop(0,'rgba(91,141,239,.36)');grad.addColorStop(1,'rgba(91,141,239,0)');x.beginPath();x.moveTo(pts[0].x,pad.t+ph);pts.forEach(p=>x.lineTo(p.x,p.y));x.lineTo(pts[pts.length-1].x,pad.t+ph);x.closePath();x.fillStyle=grad;x.fill();
 x.beginPath();pts.forEach((p,i)=>i?x.lineTo(p.x,p.y):x.moveTo(p.x,p.y));x.strokeStyle='#77a5fa';x.lineWidth=2;x.stroke();
 const maxLabels=6;for(let i=0;i<labels.length;i+=Math.max(1,Math.ceil(labels.length/maxLabels))){const p=pts[i];x.fillStyle='#7f91a7';x.fillText(labels[i].slice(5),Math.max(p.x-16,pad.l),h-8)}
}

function buildHeatmap(id,year,month,daily){
 const root=document.getElementById(id);if(!root)return;root.innerHTML='';['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d=>{const el=document.createElement('div');el.className='muted small';el.textContent=d;root.appendChild(el)});
 const first=new Date(year,month-1,1);const days=new Date(year,month,0).getDate();for(let i=0;i<first.getDay();i++){const e=document.createElement('div');e.className='heat-cell empty';root.appendChild(e)}
 const vals=Object.values(daily).map(Number);const max=Math.max(...vals,1);
 for(let d=1;d<=days;d++){const key=`${year}-${String(month).padStart(2,'0')}-${String(d).padStart(2,'0')}`;const v=Number(daily[key]||0);const ratio=Math.min(1,v/max);const hue=120-(120*ratio);const sat=55+25*ratio;const light=v?28+5*(1-ratio):15;const e=document.createElement('a');e.className='heat-cell';e.href=`/transactions?start=${key}&end=${key}`;e.style.background=`hsl(${hue} ${sat}% ${light}%)`;e.innerHTML=`<span class="heat-day">${d}</span>${v?`<span class="heat-amount">${money(v)}</span>`:''}`;root.appendChild(e)}
}

function populateSubcategorySelect(categoryEl, subcategoryEl, map, selectedValue=''){
 if(!categoryEl||!subcategoryEl)return;
 const categoryId=String(categoryEl.value||'');
 const options=(map&&map[categoryId])||[];
 subcategoryEl.innerHTML='<option value="">None</option>';
 options.forEach(item=>{
   const opt=document.createElement('option');
   opt.value=String(item.id); opt.textContent=item.name;
   if(String(selectedValue)!=='' && String(item.id)===String(selectedValue)) opt.selected=true;
   subcategoryEl.appendChild(opt);
 });
 if(selectedValue && !options.some(item=>String(item.id)===String(selectedValue))) subcategoryEl.value='';
}
