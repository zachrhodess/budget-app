import os
from datetime import datetime
from pathlib import Path

from sqlalchemy import create_engine, text
from sqlalchemy.orm import declarative_base, sessionmaker

DATA_DIR = Path(os.getenv("RHODES_DATA_DIR", "/data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
(DATA_DIR / "imports").mkdir(exist_ok=True)
(DATA_DIR / "exports").mkdir(exist_ok=True)
(DATA_DIR / "backups").mkdir(exist_ok=True)

DB_PATH = DATA_DIR / "rhodes_financial.db"
DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

# Lightweight migration framework. Future releases append a numbered migration here.
# Existing databases are never replaced; changes are applied in place.
LATEST_SCHEMA_VERSION = 4


def run_migrations():
    with engine.begin() as conn:
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at TEXT NOT NULL,
                app_version TEXT NOT NULL
            )
        """))
        applied = {row[0] for row in conn.execute(text("SELECT version FROM schema_migrations"))}

        # v1 establishes schema-version tracking for databases created by Rhodes Financial 1.0.x.
        # No user data is altered by this migration.
        if 1 not in applied:
            conn.execute(
                text("INSERT INTO schema_migrations(version, applied_at, app_version) VALUES (:v, :ts, :app)"),
                {"v": 1, "ts": datetime.now().isoformat(timespec="seconds"), "app": "1.1.0"},
            )

        # v2 updates Rhodes Financial's default category setup without deleting historical data.
        # Existing Coffee-tagged transactions keep their old reference, but Coffee is hidden
        # from new selections. Amazon is added as a Shopping subcategory.
        if 2 not in applied:
            conn.execute(text("""
                INSERT OR IGNORE INTO subcategories(category_id, name, active)
                SELECT id, 'Amazon', 1 FROM categories WHERE name = 'Shopping'
            """))
            # Move existing Coffee classifications to Dining before hiding Coffee.
            conn.execute(text("""
                UPDATE transactions
                SET subcategory_id = (
                    SELECT s2.id FROM subcategories s2
                    JOIN categories c2 ON c2.id = s2.category_id
                    WHERE c2.name = 'Food' AND s2.name = 'Dining' LIMIT 1
                )
                WHERE subcategory_id = (
                    SELECT s1.id FROM subcategories s1
                    JOIN categories c1 ON c1.id = s1.category_id
                    WHERE c1.name = 'Food' AND s1.name = 'Coffee' LIMIT 1
                )
            """))
            conn.execute(text("""
                UPDATE merchant_rules
                SET subcategory_id = (
                    SELECT s2.id FROM subcategories s2
                    JOIN categories c2 ON c2.id = s2.category_id
                    WHERE c2.name = 'Food' AND s2.name = 'Dining' LIMIT 1
                )
                WHERE subcategory_id = (
                    SELECT s1.id FROM subcategories s1
                    JOIN categories c1 ON c1.id = s1.category_id
                    WHERE c1.name = 'Food' AND s1.name = 'Coffee' LIMIT 1
                )
            """))
            conn.execute(text("""
                UPDATE subcategories
                SET active = 0
                WHERE name = 'Coffee'
                  AND category_id = (SELECT id FROM categories WHERE name = 'Food' LIMIT 1)
            """))
            conn.execute(
                text("INSERT INTO schema_migrations(version, applied_at, app_version) VALUES (:v, :ts, :app)"),
                {"v": 2, "ts": datetime.now().isoformat(timespec="seconds"), "app": "1.2.0"},
            )

        # v3 adds account identity + linked-transfer metadata for Account Intelligence.
        if 3 not in applied:
            account_columns = {row[1] for row in conn.execute(text("PRAGMA table_info(accounts)"))}
            for name, ddl in [
                ("institution", "ALTER TABLE accounts ADD COLUMN institution VARCHAR(120)"),
                ("product_name", "ALTER TABLE accounts ADD COLUMN product_name VARCHAR(160)"),
                ("aliases", "ALTER TABLE accounts ADD COLUMN aliases TEXT"),
            ]:
                if name not in account_columns:
                    conn.execute(text(ddl))

            txn_columns = {row[1] for row in conn.execute(text("PRAGMA table_info(transactions)"))}
            for name, ddl in [
                ("transfer_subtype", "ALTER TABLE transactions ADD COLUMN transfer_subtype VARCHAR(40)"),
                ("flow_direction", "ALTER TABLE transactions ADD COLUMN flow_direction VARCHAR(8)"),
                ("linked_transaction_id", "ALTER TABLE transactions ADD COLUMN linked_transaction_id INTEGER"),
                ("transfer_match_confidence", "ALTER TABLE transactions ADD COLUMN transfer_match_confidence FLOAT"),
                ("transfer_match_status", "ALTER TABLE transactions ADD COLUMN transfer_match_status VARCHAR(20)"),
            ]:
                if name not in txn_columns:
                    conn.execute(text(ddl))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_transactions_linked_transaction_id ON transactions (linked_transaction_id)"))
            conn.execute(text("""
                CREATE TABLE IF NOT EXISTS account_relationships (
                    id INTEGER PRIMARY KEY,
                    source_account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                    target_account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                    relationship_type VARCHAR(40) NOT NULL,
                    confidence FLOAT DEFAULT 1.0,
                    confirmed BOOLEAN DEFAULT 1,
                    created_at DATETIME,
                    CONSTRAINT uq_account_relationship UNIQUE(source_account_id, target_account_id, relationship_type)
                )
            """))
            conn.execute(
                text("INSERT INTO schema_migrations(version, applied_at, app_version) VALUES (:v, :ts, :app)"),
                {"v": 3, "ts": datetime.now().isoformat(timespec="seconds"), "app": "1.4.0"},
            )

        # v4 adds human-readable Transfer subcategories used by transfer intelligence.
        if 4 not in applied:
            for sub_name in [
                "Credit Card Payment", "Savings Transfer", "Investment Contribution",
                "Investment Withdrawal", "Account Transfer", "Loan Payment", "Other Transfer"
            ]:
                conn.execute(text("""
                    INSERT OR IGNORE INTO subcategories(category_id, name, active)
                    SELECT id, :name, 1 FROM categories WHERE name = 'Transfer'
                """), {"name": sub_name})
            conn.execute(
                text("INSERT INTO schema_migrations(version, applied_at, app_version) VALUES (:v, :ts, :app)"),
                {"v": 4, "ts": datetime.now().isoformat(timespec="seconds"), "app": "1.4.1"},
            )


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
