#!/bin/zsh
set -e
cd "$(dirname "$0")"

DATA_DIR="$HOME/Documents/Rhodes Financial"
mkdir -p "$DATA_DIR/imports" "$DATA_DIR/exports" "$DATA_DIR/backups"

echo "Starting Rhodes Financial..."

docker compose up -d --build
sleep 2
open http://localhost:8000

echo "Rhodes Financial is running at http://localhost:8000"
echo "Your data is stored in: $DATA_DIR"
